package net.sourceforge.easysql.editors;

import net.sourceforge.easysql.editors.sql.SQLColorProvider;
import net.sourceforge.easysql.editors.sql.SQLDocumentProvider;
import net.sourceforge.easysql.editors.sql.SQLEditorMessages;
import net.sourceforge.easysql.editors.sql.SQLSourceViewerConfiguration;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.ui.editors.text.TextEditor;
import org.eclipse.ui.ide.IGotoMarker;
import org.eclipse.ui.part.FileEditorInput;
import org.eclipse.ui.texteditor.TextOperationAction;


/**
 * Insert the type's description here.
 * @see EditorPart
 */
public class SQLEditor extends TextEditor {
    public static String ID = "net.sourceforge.easysql.editors.SQLEditor";    
    public static String MENU_ID = "#" + ID;
        
    private SQLColorProvider colorProvider;
    
    /**
     * Constructor for SampleEditor.
     */
    public SQLEditor() {
        super();
    
        colorProvider = new SQLColorProvider();
        setSourceViewerConfiguration(new SQLSourceViewerConfiguration(colorProvider));
        setDocumentProvider(new SQLDocumentProvider());
        setEditorContextMenuId(MENU_ID);
    }

    protected void createActions() {
        super.createActions();

        setAction("ContentAssistProposal", new TextOperationAction(SQLEditorMessages.getResourceBundle(), "ContentAssistProposal.", this, ISourceViewer.CONTENTASSIST_PROPOSALS)); //$NON-NLS-1$ //$NON-NLS-2$
        setAction("ContentAssistTip", new TextOperationAction(SQLEditorMessages.getResourceBundle(), "ContentAssistTip.", this, ISourceViewer.CONTENTASSIST_CONTEXT_INFORMATION)); //$NON-NLS-1$ //$NON-NLS-2$
    }

    public String getSelectedText() {
        String selected = getSourceViewer().getTextWidget().getSelectionText();

		return selected;
    }

    public String getText() {
        String text = getSourceViewer().getTextWidget().getText();

        return text;
    }

    protected void editorContextMenuAboutToShow(IMenuManager menu) {       
        super.editorContextMenuAboutToShow(menu);
    }
    
    public void dispose() {
        colorProvider.dispose();
        super.dispose();
    }

	/**
	 * Insert the method's description here.
	 * @see EditorPart#setFocus
	 */
	public void setFocus()  {
        super.setFocus();
	}

	/**
	 * Insert the method's description here.
	 * @see EditorPart#doSave
	 */
	public void doSave(IProgressMonitor monitor)  {
        super.doSave(monitor);
	}

	/**
	 * Insert the method's description here.
	 * @see EditorPart#doSaveAs
	 */
	public void doSaveAs()  {
        super.doSaveAs();
	}

	/**
	 * Insert the method's description here.
	 * @see EditorPart#gotoMarker
	 */
	public void gotoMarker(IMarker marker)  {
        //super.gotoMarker(marker);
		//Eclipse 3
		super.getAdapter(IGotoMarker.class);
	}

	/**
	 * Insert the method's description here.
	 * @see EditorPart#isDirty
	 */
	public boolean isDirty()  {
		// Only ask opened dirty files to save, not buffers
		if (getEditorInput() instanceof FileEditorInput) {
			return super.isDirty();
		}
		return false;
	}

	/**
	 * Insert the method's description here.
	 * @see EditorPart#isSaveAsAllowed
	 */
	public boolean isSaveAsAllowed()  {
		return true;
	}
    
}
