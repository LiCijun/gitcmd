package net.sourceforge.easysql.editors.sql;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.eclipse.core.resources.IStorage;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IPersistableElement;
import org.eclipse.ui.IStorageEditorInput;

/**
 * @author jtoth
 */
public class SQLEditorInput implements IStorageEditorInput {
	String name = "buffer";
	IStorage is;

	public SQLEditorInput() {
		is = new IStorage() {

			/**
			 * @see org.eclipse.core.resources.IStorage#getContents()
			 */
			public InputStream getContents() throws CoreException {
				return new ByteArrayInputStream("".getBytes());
			}

			/**
			 * @see org.eclipse.core.resources.IStorage#getFullPath()
			 */
			public IPath getFullPath() {
				return null;
			}

			/**
			 * @see org.eclipse.core.resources.IStorage#getName()
			 */
			public String getName() {
				return name;
			}

			/**
			 * @see org.eclipse.core.resources.IStorage#isReadOnly()
			 */
			public boolean isReadOnly() {
				return false;
			}

			/**
			 * @see org.eclipse.core.runtime.IAdaptable#getAdapter(Class)
			 */
			public Object getAdapter(Class adapter) {
				return null;
			}
		};
	}

    public SQLEditorInput(IStorage storage) {
        is = storage;
    }


	/**
	 * @see org.eclipse.ui.IEditorInput#exists()
	 */
	public boolean exists() {
		return true;
	}

	/**
	 * @see org.eclipse.ui.IEditorInput#getImageDescriptor()
	 */
	public ImageDescriptor getImageDescriptor() {
		return null;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @see org.eclipse.ui.IEditorInput#getName()
	 */
	public String getName() {
		return name;
	}

	/**
	 * @see org.eclipse.ui.IEditorInput#getPersistable()
	 */
	public IPersistableElement getPersistable() {
		return null;
	}

	/**
	 * @see org.eclipse.ui.IEditorInput#getToolTipText()
	 */
	public String getToolTipText() {
		return "Execute SQL";
	}

	/**
	 * @see org.eclipse.core.runtime.IAdaptable#getAdapter(Class)
	 */
	public Object getAdapter(Class adapter) {
		return null;
	}

	/**
	 * @see org.eclipse.ui.IStorageEditorInput#getStorage()
	 */
	public IStorage getStorage() throws CoreException {
		return is;
	}

}
