package net.sourceforge.easysql.editors.sql;

import java.util.ArrayList;

/**
 * @author Joey
 *
 */
public class SQLParser {

	public static String[] parseSQL(String sql) {
		char[] c = sql.toCharArray();

		char stringChar = 'x';
		boolean inComment = false;

		StringBuffer sb = new StringBuffer();
		ArrayList statements = new ArrayList();

		for (int i = 0; i < c.length; i++) {

			if (!inComment) {
				// if in comment and escaping ' or ", via \' \", skip
				if (stringChar != 'x' && c[i] == '\\') {
					sb.append(c[i]);
					int nextChar = i + 1;
					if (c[nextChar] == '\'' || c[nextChar] == '"') {
						sb.append(c[i]);
						continue;
					}
				}

				if (c[i] == '\'' || c[i] == '"') {
					if (c[i] == stringChar) {
						stringChar = 'x';
						sb.append(c[i]);
					} else {
						stringChar = c[i];
						sb.append(c[i]);
					}
					continue;
				}

				if (c[i] == '-' && c[i + 1] == '-') {
					inComment = true;
					i++;
					//                    sb.append("--");
					continue;
				}

			}

			// if in comment and end of line, get out of comment
			if (inComment == true && c[i] == Character.LINE_SEPARATOR) {
				//System.out.println("char: " + i);
				inComment = false;
				continue;
			}

			if (inComment == true || c[i] == 13 || c[i] == 10) {
//				log.info("inComment: " + (int) c[i]);
				if (c[i] == 10) {
					sb.append(" ");
				}
				continue;
			}

			// if end of statement
			if (c[i] == ';') {
				statements.add(sb.toString());
				sb = new StringBuffer();
				continue;
			}

			if (!inComment) {
				sb.append(c[i]);
				//System.out.println("not inComment: " + (int)c[i]);
			}
		}

		if (statements.size() == 0) {
			statements.add(sb.toString());
		}

		String[] stmts = new String[statements.size()];
		statements.toArray(stmts);

		return stmts;
	}

	public static void main(String[] args) {
		parseSQL(
			"select * from table where column = \"po\\\"opy\"; --don't include this"
				+ '\n'
				+ " another  monkey;");
	}
}
