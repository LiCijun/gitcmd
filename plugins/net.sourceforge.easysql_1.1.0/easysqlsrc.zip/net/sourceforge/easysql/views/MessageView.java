package net.sourceforge.easysql.views;

import java.text.DateFormat;
import java.util.Date;

import net.sourceforge.easysql.EasySQLPlugin;
import net.sourceforge.easysql.ImageCache;
import net.sourceforge.easysql.actions.ClearMessagesAction;

import org.eclipse.core.runtime.ILog;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

/**
 * Insert the type's description here.
 * @see ViewPart
 */
public class MessageView extends ViewPart {
	private static Object SEMAPHORE = new Object();
	private static MessageView instance;

	public static String ID = "net.sourceforge.easysql.views.MessageView";

	public static Text text;
	public static ILog log;

	private boolean loaded = false;

	/**
	 * The constructor.
	 */
	public MessageView() {
		instance = this;
	}

	// Always returns the first created instance of this class
	public static MessageView getInstance() {
		synchronized (SEMAPHORE) {
            if (instance == null) {
                instance = new MessageView();
            }
		}
		return instance;
	}

	protected void createToolbar() {
		IToolBarManager toolbarManager = getViewSite().getActionBars().getToolBarManager();
		ClearMessagesAction clearMessagesAction = new ClearMessagesAction();
		clearMessagesAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.REMOVE_ICON));
		toolbarManager.add(clearMessagesAction);
	}

	public void clearMessages() {
		if (text != null) {
			text.setText("");
		}
	}

	/**
	 * Insert the method's description here.
	 * @see ViewPart#createPartControl
	 */
	public void createPartControl(Composite parent) {

		this.loaded = true;

		createToolbar();

		text = new Text(parent, SWT.BORDER | SWT.MULTI | SWT.WRAP | SWT.V_SCROLL | SWT.READ_ONLY);
		text.setLayoutData(new GridData(GridData.FILL_BOTH));

		// Possibly use log later
		log = EasySQLPlugin.getInstance().getLog();
	}

	public void addMessage(String message) {
		String time = DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(System.currentTimeMillis()));
		message = time + ": " + message + EasySQLPlugin.NEWLINE;
		if (text != null && isLoaded()) {
			text.setText(message + text.getText());
		}

		// dont�t give focus
		//show()
	}

	public void addMessage(Throwable throwable) {
		// to evict NullPointer
		if(throwable!=null){
			addMessage(throwable.getClass().getName() + " : " + throwable.getMessage());
		}
		else{
			addMessage("throwable is null"); 
		}
	}

	/**
	 * Insert the method's description here.
	 * @see ViewPart#setFocus
	 */
	public void setFocus() {
		if (text != null) {
			text.setFocus();
		}
	}

	/**
	 * @see org.eclipse.ui.IWorkbenchPart#dispose()
	 */
	public void dispose() {
		this.loaded = false;
		super.dispose();
	}

	public boolean isLoaded(){
		return this.loaded;
	}
}