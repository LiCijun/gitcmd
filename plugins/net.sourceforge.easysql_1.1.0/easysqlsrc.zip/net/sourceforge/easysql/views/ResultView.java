package net.sourceforge.easysql.views;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import net.sourceforge.easysql.EasySQLPlugin;
import net.sourceforge.easysql.EasySQLUtils;
import net.sourceforge.easysql.ImageCache;
import net.sourceforge.easysql.ViewToolBarUtils;
import net.sourceforge.easysql.actions.ExportAction;
import net.sourceforge.easysql.views.connection.ColumnModel;
import net.sourceforge.easysql.views.connection.ConnectionContentProvider;
import net.sourceforge.easysql.views.connection.ConnectionModel;
import net.sourceforge.easysql.views.connection.InvisibleModel;
import net.sourceforge.easysql.views.connection.Model;
import net.sourceforge.easysql.views.connection.TableModel;

import org.apache.log4j.Logger;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

/**
 * Insert the type's description here.
 * 
 * @see ViewPart
 */
public class ResultView extends ViewPart {
    private static Logger log = Logger.getLogger(ResultView.class);

    private static Object SEMAPHORE = new Object();

    private static ResultView instance;

    private static int row, column;

    private static String oldValue;

    private static ResultSetMetaData rsmd;

    public static String ID = "net.sourceforge.easysql.views.ResultView";

    CTabFolder tablesTabFolder;

    Composite parent;

    private boolean loaded = false;

    /**
     * The constructor.
     */
    public ResultView() {
        instance=this;
    }

    // Always returns the first created instance of this class
    public static ResultView getInstance() {
        synchronized (SEMAPHORE) {
            if(instance == null) {
                instance = new ResultView();
            }
        }
        return instance;
    }

    /**
     * Insert the method's description here.
     * 
     * @see ViewPart#createPartControl
     */
    public void createPartControl(Composite parent) {

        this.loaded = true;

        this.parent = parent;
        tablesTabFolder = new CTabFolder(parent, SWT.BORDER | SWT.CLOSE);

        // Refresh Action
        Action actionRefresh = new Action() {
            public void run() {
                ConnectionView view = ConnectionView.getInstance();
                CTabItem cTabItem = tablesTabFolder.getSelection();
                if(cTabItem != null) {
                    try {
                        view.executeQuery(cTabItem.getToolTipText(), false);
                    }
                    catch (SQLException e) {
                        MessageDialog.openError(getSite().getShell(), "Error", e.getMessage());
                    }
                }
            }
        };

        // Copy to ClipBoard
        Action copyAction = new Action() {
            public void run() {
                String query = getTableViewSQLQuery();
                if(query!=null) {
                    EasySQLUtils.copyToClipBoard(query, getSite().getShell());
                }
            }
        };

        copyAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.COPY_ICON));
        copyAction.setToolTipText("Copy To ClipBoard");

        actionRefresh.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.REFRESH_ICON));
        actionRefresh.setToolTipText("Refresh");

        // Close All Tabs
        Action closeAllTabsAction = new Action() {
			public void run() {
				CTabItem[] itens = tablesTabFolder.getItems();
				if(itens != null) {
					for (int i = 0; i < itens.length; i++) {
						itens[i].dispose();
					}
				}
			}
		};

        closeAllTabsAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.REMOVE_ICON));
        closeAllTabsAction.setText("Close all Tabs");
        closeAllTabsAction.setToolTipText("Close all Tabs");

        // -- Create ToolBar --
        ViewToolBarUtils.createMenuAndToolBar(getViewSite(), new Action[] { copyAction, actionRefresh }, new Action[] {closeAllTabsAction});
    }

    public void addResultSet(ResultSet rs, final String query, boolean newTab) throws SQLException {

        if(tablesTabFolder == null) {
            MessageDialog.openWarning(EasySQLPlugin.getShell(), "EasySQL", "Please, open the Results View!");
            return;
        }

        if(newTab == false) {
            //close the previous tab
            if(tablesTabFolder.getItemCount() != 0) {
                tablesTabFolder.getSelection().dispose();
            }
        }

        final Table resultSetTable = new Table(tablesTabFolder, SWT.BORDER | SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL | SWT.FULL_SELECTION);

        // Table Name
        rsmd = rs.getMetaData();
        String tableName = configureTableName(query, resultSetTable);

        resultSetTable.setLayoutData(new GridData(GridData.FILL_BOTH));
        resultSetTable.setLinesVisible(true);
        resultSetTable.setHeaderVisible(true);

        // to edit the current cell
        final TableEditor editor = new TableEditor(resultSetTable);
        editor.horizontalAlignment = SWT.LEFT;
        editor.grabHorizontal = true;
        editor.minimumWidth = 20;

        //Create new tab
        final CTabItem tabItem = new CTabItem(tablesTabFolder, SWT.NONE);

        // Add Listener for Right-Click Menu
        resultSetTable.addMouseListener(new MouseListener() {

            public void mouseDoubleClick(MouseEvent e) {
                try {
                    editTableListener(resultSetTable, editor, e);
                }
                catch (SQLException e1) {
                    log.error(e1, e1);
                }
            }

            public void mouseDown(MouseEvent e) {
                if(e.button != 1) {
                    Menu menu = new Menu(parent);
                    MenuItem item = new MenuItem(menu, SWT.NONE);
                    item.setText("Export Data");
                    menu.setVisible(true);
                    item.addSelectionListener(new SelectionListener() {
                        public void widgetSelected(SelectionEvent e) {
                            ExportAction exportAction = new ExportAction();
                            exportAction.init(getInstance());
                            exportAction.run();
                        }

                        public void widgetDefaultSelected(SelectionEvent e) {
                        }
                    });

                    item = new MenuItem(menu, SWT.NONE);
                    item.setText("----------------------");
                    menu.setVisible(true);

                    // Delete selected Line
                    item = new MenuItem(menu, SWT.NONE);
                    item.setText("Delete selected line");
                    menu.setVisible(true);
                    item.addSelectionListener(new SelectionListener() {
                        public void widgetSelected(SelectionEvent e) {
                            Action action = new Action() {
                                public void run() {
                                    int count = delete(resultSetTable, editor);
                                    if(count > 0) {
                                        try {
                                            ConnectionContentProvider.getInstance().executeQuery(query);
                                        }
                                        catch (SQLException e) {
                                            MessageDialog.openError(getSite().getShell(), "Error", e.getMessage());
                                        }
                                    }
                                }
                            };
                            action.run();
                        }

                        public void widgetDefaultSelected(SelectionEvent e) {
                        }
                    });
                }
            }

            public void mouseUp(MouseEvent e) {
            }
        });

        tabItem.setText(tableName);
        tabItem.setToolTipText(query);
        tabItem.setControl(resultSetTable);

        getInstance().bindResultSet(rs, resultSetTable, tableName);

        // Set focus on new tab
        tablesTabFolder.setSelection(tablesTabFolder.getItemCount() - 1);

        // Bring to front
        getSite().getPage().activate(instance);
    }

    /**
     * @param query
     * @param resultSetTable
     * @return
     * @throws SQLException
     */
    private String configureTableName(final String query, final Table resultSetTable) throws SQLException {
        String tableName = rsmd.getTableName(1);

        if(tableName == null || (tableName != null && tableName.trim().length() == 0)) {
            tableName = EasySQLUtils.getTableNameFromQuery(query);
        }

        if(tableName == null || tableName.trim().length() == 0) {
            tableName = findTableName(query);
            if(tableName == null || tableName.trim().length() == 0) {
                //MessageDialog.openWarning(getSite().getShell(),"","Can�t find
                // table name!");
                MessageView.getInstance().addMessage("Can�t find table name! ->" + query);
            }
        }
        resultSetTable.setToolTipText(tableName);
        return tableName;
    }

    private void bindResultSet(ResultSet rs, final Table table, final String tableName) {
        try {
            rsmd = rs.getMetaData();

            int cols = rsmd.getColumnCount();

            // Add columns
            for (int i = 1; i <= cols; i++) {
                TableColumn column = new TableColumn(table, SWT.NONE);
                final String columnName = rsmd.getColumnName(i);
                column.setText(columnName);

                column.addListener(SWT.Selection, new Listener() {
                    public void handleEvent(Event event) {
                        // sort column

                        ConnectionModel connectionModel = ConnectionView.getInstance().getSelectedConnection();

                        if(connectionModel == null) {
                            MessageDialog.openInformation(getSite().getShell(), "Select a Connection", "Please select a connection!");
                            return;
                        }

                        String query = getTableViewSQLQuery();

                        if(query != null) {
                            int idx = query.toUpperCase().indexOf("ORDER BY");
                            if(idx != -1) {
                                query = query.substring(0,idx)+ " ORDER BY " + columnName;
                            }
                            else {
                                query += " ORDER BY " + columnName;
                            }
                        }else {
                            query = "select * from " + tableName + " ORDER BY " + columnName;
                        }
                        try { 
                            MessageView.getInstance().addMessage(query);
                            ConnectionView.getInstance().executeQuery(query, false);
                        }
                        catch (SQLException e) {
                            MessageDialog.openError(getSite().getShell(), "Error", e.getMessage());
                        }
                    }
                });
            }

            // Add data
            while (rs.next()) {
                TableItem item = new TableItem(table, SWT.NONE);
                for (int i = 0; i < cols; i++) {
                    String value = rs.getString(i + 1);
                    if(value == null) {
                        item.setText(i, "<null>");
                    }
                    else {
                        item.setText(i, value.trim());
                    }
                }
            }

            // Resize columns
            for (int i = 0; i < cols; i++) {
                table.getColumn(i).pack();
            }

        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * TODO: Ao fazer update da chave. Pegar o valor antigo
     */
    private static void editTableListener(final Table table, final TableEditor editor, MouseEvent e) throws SQLException {
        Point pt = new Point(e.x, e.y);

        TableItem item = table.getItem(pt);
        if(item == null)
            return;
        for (int i = 0; i < table.getColumnCount(); i++) {
            Rectangle rect = item.getBounds(i);
            if(rect.contains(pt)) {
                row = table.indexOf(item);
                column = i;
                break;
            }
        }

//      try {
//          final boolean readOnly = rsmd.isReadOnly(column);
//      } catch (Exception e) {
//          // bug no DB2
//      }

        // Clean up any previous editor control
        Control oldEditor = editor.getEditor();
        if(oldEditor != null)
            oldEditor.dispose();

        // Identify the selected row
        item = (TableItem) table.getItem(row);
        oldValue = item.getText(column);

        if(item == null) {
            log.warn("item is null");
            return;
        }

        // The control that will be the editor must be a child of the Table
        Text newEditor = new Text(table, SWT.NONE);

        newEditor.setText(item.getText(column));
        newEditor.addModifyListener(new ModifyListener() {
            public void modifyText(ModifyEvent e) {
                Text text = (Text) editor.getEditor();
                editor.getItem().setText(column, text.getText());
            }
        });
        newEditor.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                if(e.keyCode == 13) {
                    // to implement update query!
                    enter(table, editor);
                }
            }

            public void keyReleased(KeyEvent e) {
            }
        });

        newEditor.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
            }

            public void focusLost(FocusEvent e) {
                enter(table, editor);
            }

        });

        newEditor.selectAll();
        newEditor.setFocus();
        editor.setEditor(newEditor, item, column);
    }

    /**
     * Update selected row
     * 
     * @param table
     * @param editor
     */
    private static void enter(final Table table, final TableEditor editor) {
        Control oldEditor = editor.getEditor();
        if(oldEditor != null)
            oldEditor.dispose();

        TableItem item = (TableItem) table.getItem(row);
        String newValue = item.getText(column);
        if(newValue.equals(oldValue))
            return;

        table.getItem(row);
        //updateTableItem(row, oldValue, column);

        TableColumn selectedColumn = table.getColumn(column);

        String tableName = table.getToolTipText();
        TableModel tableModel = EasySQLUtils.getTableModelByName(tableName);

        ColumnModel columnModel = (ColumnModel) tableModel.getChildByName(selectedColumn.getText());
        if(columnModel == null) {
            log.info("expanding table");
            ConnectionContentProvider.getInstance().expandTableModel(tableModel, false);
            columnModel = (ColumnModel) tableModel.getChildByName(selectedColumn.getText());
            if(columnModel == null) {
                log.info("column " + selectedColumn.getText() + " not found");
                return;
            }
        }

        StringBuffer query = new StringBuffer("update " + tableName + " set " + selectedColumn.getText() + "=");
        if(columnModel.isStringClass()) {
            query.append("'");
        }
        query.append(newValue);
        if(columnModel.isStringClass()) {
            query.append("'");
        }

        String where = getWhereStatement(table, tableModel);
        if(where != null) {
            query.append(" where " + where);
            log.info(query);
            try {
                int count = ConnectionContentProvider.getInstance().executeQuery(query.toString());
                if(count <= 0) {
                    MessageDialog.openWarning(getInstance().getSite().getShell(), "Warning", "The row can�t updated!");
                }
            }
            catch (SQLException e) {
                MessageDialog.openError(getInstance().getSite().getShell(), "Error", e.getMessage());
            }
        }
        else {
            MessageDialog.openWarning(getInstance().getSite().getShell(), "", "Primary Key not found!");
        }
    }

    /**
     * Delete selected row
     * 
     * @param table
     * @param editor
     */
    private static int delete(final Table table, final TableEditor editor) {
        int count = 0;

        log.debug("Deleting row: " + row);

        String tableName = table.getToolTipText();
        TableModel tableModel = EasySQLUtils.getTableModelByName(tableName);
        Model[] columns = tableModel.getChildren();
        //expand to find the columns
        if(columns != null && columns.length > 0 && columns[0] instanceof InvisibleModel) {
            ConnectionContentProvider.getInstance().expandTableModel(tableModel, false);
        }

        StringBuffer initialQuery = new StringBuffer("delete from " + tableName);

        TableItem items[] = table.getSelection();

        TableColumn[] tableColumns = table.getColumns();
        for (int i = 0; i < items.length; i++) {
            StringBuffer query = new StringBuffer(initialQuery.toString());
            String where = null;
            TableItem tableItem = items[i];
            for (int j = 0; j < tableColumns.length; j++) {
                ColumnModel column = (ColumnModel) tableModel.getChildByName(tableColumns[j].getText());
                if(column != null && column.isPrimaryKey()) {
                    where = where == null ? column.getName() + "=" : where + " AND " + column.getName() + "=";
                    if(column.isStringClass()) {
                        where += "'";
                    }
                    where += tableItem.getText(j);
                    if(column.isStringClass()) {
                        where += "'";
                    }
                }
            }

            if(where != null) {
                query.append(" where " + where);
                log.info(query);
                MessageView.getInstance().addMessage(query.toString());
                try {
                    count += ConnectionContentProvider.getInstance().executeQuery(query.toString());
                }
                catch (SQLException e) {
                    MessageDialog.openError(getInstance().getSite().getShell(), "Error", e.getMessage());
                }
            }
            else {
                MessageDialog.openWarning(getInstance().getSite().getShell(), "", "Primary Key not found!");
                break;
            }
        }

        return count;
    }

    /**
     * Finds Where Statemet. Look at Primary Keys
     * 
     * @param table
     * @param tableModel
     * @return
     */
    private static String getWhereStatement(final Table table, TableModel tableModel) {
        String where = null;
        TableColumn[] columns = table.getColumns();
        // Finds Where Statemet. Look at Primary Keys
        for (int i = 0; i < columns.length; i++) {
            ColumnModel column = EasySQLUtils.getColumnModelByName(tableModel, columns[i].getText());

            if(column != null && column.isPrimaryKey()) {
                StringBuffer sb = new StringBuffer(column.getName() + "=");
                if(column.isStringClass()) {
                    sb.append("'");
                }
                sb.append(table.getItem(row).getText(i));
                if(column.isStringClass()) {
                    sb.append("'");
                }

                where = where == null ? sb.toString() : where + " AND " + sb.toString();
            }
        }
        return where;
    }

    public Table getSelectedTable() {
        return (Table) tablesTabFolder.getSelection().getControl();
    }

    /**
     * Insert the method's description here.
     * 
     * @see ViewPart#setFocus
     */
    public void setFocus() {
    }

    /**
     * Return the table name of the query. The table name is necessary for
     * delete and update queries after.
     * 
     * @param query
     * @return
     */
    private String findTableName(String query) {
        char[] array = query.substring(query.toLowerCase().indexOf("from") + 4).toCharArray();
        String tableName = "";
        boolean start = false;
        for (int j = 0; j < array.length; j++) {
            if(array[j] == ' ') {
                if(!start) {
                    start = true;
                    continue;
                }
                else {
                    //end
                    break;
                }
            }
            else if(array[j] == ',') {
                break; // end
            }
            else {
                tableName += array[j];
            }
        }
        return tableName;
    }
    
    /**
     * @see org.eclipse.ui.IWorkbenchPart#dispose()
     */
    public void dispose() {
        this.loaded = false;
        super.dispose();
    }

    public boolean isLoaded(){
        return this.loaded;
    }

    private String getTableViewSQLQuery() {
        CTabItem cTabItem = tablesTabFolder.getSelection();
        if(cTabItem != null) {
            CTabItem localCTabItem = tablesTabFolder.getSelection();
            if(localCTabItem != null) {
                return localCTabItem.getToolTipText();
            }
        }
        return null;
    }
}