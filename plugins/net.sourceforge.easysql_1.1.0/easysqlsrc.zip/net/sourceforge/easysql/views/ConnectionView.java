package net.sourceforge.easysql.views;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;

import net.sourceforge.easysql.EasySQLPlugin;
import net.sourceforge.easysql.EasySQLUtils;
import net.sourceforge.easysql.ImageCache;
import net.sourceforge.easysql.ViewToolBarUtils;
import net.sourceforge.easysql.actions.ConnectAction;
import net.sourceforge.easysql.actions.CopyConnectionAction;
import net.sourceforge.easysql.actions.DisconnectAction;
import net.sourceforge.easysql.actions.EditConnectionAction;
import net.sourceforge.easysql.actions.ExecFileAction;
import net.sourceforge.easysql.actions.ExportXMLAction;
import net.sourceforge.easysql.actions.InsertAction;
import net.sourceforge.easysql.actions.JoinAction;
import net.sourceforge.easysql.actions.LoadXMLAction;
import net.sourceforge.easysql.actions.NewBufferAction;
import net.sourceforge.easysql.actions.NewConnectionAction;
import net.sourceforge.easysql.actions.RefreshAction;
import net.sourceforge.easysql.actions.RemoveConnectionAction;
import net.sourceforge.easysql.actions.SelectConnectionAction;
import net.sourceforge.easysql.actions.SelectCountTableAction;
import net.sourceforge.easysql.actions.SelectDatabaseAction;
import net.sourceforge.easysql.actions.SelectTableAction;
import net.sourceforge.easysql.actions.WhereAction;
import net.sourceforge.easysql.editors.SQLEditor;
import net.sourceforge.easysql.views.connection.ColumnModel;
import net.sourceforge.easysql.views.connection.ConnectionContentProvider;
import net.sourceforge.easysql.views.connection.ConnectionLabelProvider;
import net.sourceforge.easysql.views.connection.ConnectionModel;
import net.sourceforge.easysql.views.connection.DatabaseModel;
import net.sourceforge.easysql.views.connection.Model;
import net.sourceforge.easysql.views.connection.TableModel;

import org.apache.log4j.Logger;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ITreeViewerListener;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeExpansionEvent;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.ui.part.ViewPart;

/**
 * Insert the type's description here.
 * @see ViewPart
 */
public class ConnectionView extends ViewPart {
	private Logger log = Logger.getLogger(ConnectionView.class);
	private static Object SEMAPHORE = new Object();
	private static ConnectionView instance;

	public static String ID = "net.sourceforge.easysql.views.ConnectionView";
	public static String MENU_ID = "#" + ID;

	public TreeViewer treeViewer;

	// Actions
	private NewConnectionAction newConnectionAction;
	private EditConnectionAction editConnectionAction;
	private RemoveConnectionAction removeConnectionAction;
    private CopyConnectionAction copyConnectionAction;

	private ConnectAction connectAction;
	private DisconnectAction disconnectAction;

	private SelectDatabaseAction selectDatabaseAction;
	private SelectConnectionAction selectConnectionAction;

	private RefreshAction refreshAction;
	private LoadXMLAction loadXMLAction;
	private ExportXMLAction exportXMLAction;
//	private ImportAction importAction;
    private ExecFileAction execFileAction;

	private SelectTableAction selectTableAction = null;
	private SelectCountTableAction selectCountTableAction = null;
    private InsertAction insertAction = null;
    private WhereAction whereAction = null;
	private JoinAction joinAction = null;
	private NewBufferAction newBufferAction = null;

	/**
	 * The constructor.
	 */
	public ConnectionView() {
		instance = this;
	}

	// Always returns the first created instance of this class
	public static ConnectionView getInstance() {
		synchronized (SEMAPHORE) {
			if (instance == null) {
				instance = new ConnectionView();
			}
		}
		return instance;
	}

	private void initActions() {
		// New Connection
		newConnectionAction = new NewConnectionAction();
		newConnectionAction.setText("New Connection");
		newConnectionAction.setToolTipText("Create new database connection");
		newConnectionAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.DISCONNECTED_ICON));
		newConnectionAction.init(this);

		// Edit Connection
		editConnectionAction = new EditConnectionAction();
		editConnectionAction.setText("Edit Connection");
		editConnectionAction.setToolTipText("Edit existing database connection");
		editConnectionAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.DISCONNECTED_ICON));
		editConnectionAction.init(this);

		// Remove Connection
		removeConnectionAction = new RemoveConnectionAction();
		removeConnectionAction.setText("Remove Connection");
		removeConnectionAction.setToolTipText("Remove database connection");
		removeConnectionAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.REMOVE_ICON));
		removeConnectionAction.init(this);
        
        // Copy Connection
        copyConnectionAction = new CopyConnectionAction();
        copyConnectionAction.setText("Copy Connection");
        copyConnectionAction.setToolTipText("Copy database connection");
        copyConnectionAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.COPY_ICON));
        copyConnectionAction.init(this);

		// Connect
		connectAction = new ConnectAction();
		connectAction.setText("Connect");
		connectAction.setToolTipText("Connect to database");
		connectAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.CONNECTED_ICON));
		connectAction.init(this);

		// Disconnect
		disconnectAction = new DisconnectAction();
		disconnectAction.setText("Disconnect");
		disconnectAction.setToolTipText("Disconnect from database");
		disconnectAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.DISCONNECTED_ICON));
		disconnectAction.init(this);

		// Select Database
		selectDatabaseAction = new SelectDatabaseAction();
		selectDatabaseAction.setText("Select Database");
		selectDatabaseAction.setToolTipText("Select Database");
		selectDatabaseAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.SELECTED_DATABASE_ICON));
		selectDatabaseAction.init(this);

		// Select Connection
		selectConnectionAction = new SelectConnectionAction();
		selectConnectionAction.setText("Select Connection");
		selectConnectionAction.setToolTipText("Select Connection");
		selectConnectionAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.SELECTED_CONNECTED_ICON));
		selectConnectionAction.init(this);

		// Refresh
		refreshAction = new RefreshAction();
		refreshAction.setText("Refresh");
		refreshAction.setToolTipText("Refresh Item");
		refreshAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.REFRESH_ICON));
		refreshAction.init(this);

		//LoadXMLAction
		loadXMLAction = new LoadXMLAction();
		loadXMLAction.setText("Load XML");
		loadXMLAction.setToolTipText("Load XML");
		loadXMLAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.IMPORT_ICON));
		loadXMLAction.init(this);

		//ExportXMLAction
		exportXMLAction = new ExportXMLAction();
		exportXMLAction.setText("Export XML");
		exportXMLAction.setToolTipText("Export XML");
		exportXMLAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.EXPORT_ICON));
		exportXMLAction.init(this);

//		// Import
//		importAction = new ImportAction();
//		importAction.setText("Import");
//		importAction.setToolTipText("Import Data");
//		importAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.IMPORT_ICON));
//		importAction.init(this);

        // Exec File
        execFileAction = new ExecFileAction();
        execFileAction.setText("Execute/Import File");
        execFileAction.setToolTipText("Execute File");
        execFileAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.RUN_ICON));
        execFileAction.init(this);

		// Select Table
		selectTableAction = new SelectTableAction();
		selectTableAction.setText("Select Table");
		selectTableAction.setToolTipText("Select Table");
		selectTableAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.RUN_ICON));
		selectTableAction.init(this);

		// Join Query
		joinAction = new JoinAction();
		joinAction.setText("Join Tables");
		joinAction.setToolTipText("Join Tables");
		joinAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.RUN_ICON));
		joinAction.init(this);

		// Select Count(*) Table
		selectCountTableAction = new SelectCountTableAction();
		selectCountTableAction.setText("Select count(*)");
		selectCountTableAction.setToolTipText("Select count(*)");
		selectCountTableAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.RUN_ICON));
		selectCountTableAction.init(this);

        // Insert data
        insertAction = new InsertAction();
        insertAction.setText("Insert");
        insertAction.setToolTipText("Insert data into table");
        insertAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.INSERT_ICON));
        insertAction.init(this);

        whereAction = new WhereAction();
        whereAction.setText("Query");
        whereAction.setToolTipText("Filter statement with the where clause");
        whereAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.RUN_ICON));
        whereAction.init(this);

		// SQL Editor Action
		newBufferAction = new NewBufferAction();
		newBufferAction.setText("Open SQL Editor");
		newBufferAction.setToolTipText("Open SQL Editor");
		newBufferAction.setImageDescriptor(ImageCache.getImageDescriptor(ImageCache.SQLEDITOR_ICON));
		newBufferAction.init(this);
	}

	public void createPartControl(Composite parent) {
		initActions();

		treeViewer = new TreeViewer(parent);
		treeViewer.setContentProvider(ConnectionContentProvider.getInstance());
		treeViewer.setLabelProvider(ConnectionLabelProvider.getInstance());
		treeViewer.setInput(ConnectionContentProvider.getInstance().getInvisibleRootModel());

		treeViewer.addTreeListener(new ITreeViewerListener() {
			public void treeCollapsed(TreeExpansionEvent event) {
			}

			public void treeExpanded(TreeExpansionEvent event) {
				Model model = (Model) event.getElement();

				// Deselect everything, otherwise tree will refresh to top of selected item
				treeViewer.setSelection(null);

				if (model == null) {
					log.debug("treeExpanded: model == null");
				} else if (model instanceof ConnectionModel) {
				} else if (model instanceof DatabaseModel) {
					DatabaseModel databaseModel = (DatabaseModel) model;
					expandDatabaseModel(databaseModel);
				} else if (model instanceof TableModel) {
					TableModel tableModel = (TableModel) model;
					expandTableModel(tableModel);
				}
			}
		});

		MenuManager menuManager = new MenuManager("Menu DooD", MENU_ID);
		menuManager.setRemoveAllWhenShown(true);
		Menu contextMenu = menuManager.createContextMenu(treeViewer.getControl());
		treeViewer.getControl().setMenu(contextMenu);

		treeViewer.addDoubleClickListener(new IDoubleClickListener() {
			public void doubleClick(DoubleClickEvent event) {
				Model model = getSelectedModel();
				if (model instanceof ConnectionModel) {
					connectAction.run();
				} else if (model instanceof DatabaseModel) {
					selectDatabaseAction.run();
				} else if (model instanceof TableModel) {
					expandTableModel((TableModel) model);
				}
			}
		});
        
		menuManager.addMenuListener(new IMenuListener() {
			public void menuAboutToShow(IMenuManager mgr) {
				Model model = getSelectedModel();

				if (model == null) {
					mgr.add(newConnectionAction);
				} else if (model instanceof ConnectionModel) {
					ConnectionModel connectionModel = (ConnectionModel) model;

					if (connectionModel.getConnection() == null) {
						mgr.add(connectAction);
					} else {
						mgr.add(selectConnectionAction);
						mgr.add(refreshAction);
						mgr.add(new Separator());
						mgr.add(disconnectAction);
						mgr.add(new Separator());
					}

					mgr.add(newConnectionAction);
					mgr.add(editConnectionAction);
					mgr.add(removeConnectionAction);
                    mgr.add(copyConnectionAction);
				} else if (model instanceof DatabaseModel) {
					mgr.add(selectDatabaseAction);
					mgr.add(refreshAction);
				} else if (model instanceof TableModel) {
					mgr.add(refreshAction);
					mgr.add(selectTableAction);
					mgr.add(selectCountTableAction);
					mgr.add(whereAction);
                    mgr.add(joinAction);
                    mgr.add(insertAction);
//					mgr.add(importAction);
				} else if (model instanceof ColumnModel) {
					//					StructuredSelection selection = (StructuredSelection) treeViewer.getSelection();
					//					Iterator iter = selection.iterator();
					//					while (iter.hasNext()) {
					//						Object o = (Object) iter.next();
					//						System.out.println(o);
					//					}
					mgr.add(selectTableAction); // selected columns!
                    mgr.add(whereAction); // where condition
					mgr.add(joinAction);
					mgr.add(insertAction);
				}
			}
		});

		//		-- Create ToolBar --
		ViewToolBarUtils.createMenuAndToolBar(
			getViewSite(),
			new Action[] { newBufferAction, selectTableAction,insertAction },
			new Action[] { refreshAction,loadXMLAction,exportXMLAction,execFileAction});
	}

	public void addConnection(ConnectionModel connectionModel) {
		ConnectionContentProvider.getInstance().getInvisibleRootModel().addChild(connectionModel);
		changedConnection();
	}

	public void removeConnection(ConnectionModel connectionModel) {
		ConnectionContentProvider.getInstance().getInvisibleRootModel().removeChild(connectionModel);
		changedConnection();
	}

	public void changedConnection() {
		ConnectionContentProvider.getInstance().setHasChanged(true);
		treeViewer.refresh();
	}

	public void connect(ConnectionModel connectionModel) {
		ConnectionContentProvider.getInstance().connect(connectionModel);
		expandConnectionModel(connectionModel);
	}

	public void disconnect(ConnectionModel connectionModel) {
		ConnectionContentProvider.getInstance().disconnect(connectionModel);
		treeViewer.refresh();
	}

	public void executeQuery(SQLEditor editor, boolean newTab) throws SQLException {
		ConnectionContentProvider.getInstance().executeQuery(editor, newTab);
	}

	public void executeQuery(String query, boolean newTab) throws SQLException {
		ConnectionContentProvider.getInstance().executeQuery(query, newTab);
	}

	public Model getSelectedModel() {
		return (Model) ((StructuredSelection) treeViewer.getSelection()).getFirstElement();
	}

	public StructuredSelection getSelection() {
		return (StructuredSelection)treeViewer.getSelection();
	}

	public void setSelectedDatabase(DatabaseModel databaseModel) {
		ConnectionContentProvider.getInstance().setSelectedDatabaseModel(databaseModel);
		// setSelectedConnection to the database's parent
		ConnectionModel connectionModel =
			ConnectionContentProvider.getInstance().getParentConnectionModel(databaseModel);
		ConnectionContentProvider.getInstance().setSelectedConnectionModel(connectionModel);
		expandDatabaseModel(databaseModel);
		try {
			connectionModel.getConnection().setCatalog(databaseModel.getName());
		} catch (SQLException e) {
			MessageView.getInstance().addMessage(e.getMessage());
		}

		//			treeViewer.refresh();
	}

	public DatabaseModel getSelectedDatabase() {
		return ConnectionContentProvider.getInstance().getSelectedDatabaseModel();
	}

	public void setSelectedConnection(ConnectionModel connectionModel) {
		ConnectionContentProvider.getInstance().setSelectedConnectionModel(connectionModel);
		ConnectionContentProvider.getInstance().setSelectedDatabaseModel(null);
		expandConnectionModel(connectionModel);
		//			treeViewer.refresh();
	}

	public ConnectionModel getSelectedConnection() {
		return ConnectionContentProvider.getInstance().getSelectedConnectionModel();
	}

	public void expandConnectionModel(ConnectionModel connectionModel) {
		treeViewer.collapseToLevel(connectionModel, TreeViewer.ALL_LEVELS);
		treeViewer.refresh();
		treeViewer.expandToLevel(connectionModel, 1);
	}

	public void expandDatabaseModel(DatabaseModel databaseModel) {
		ConnectionContentProvider.getInstance().expandDatabaseModel(databaseModel, false);
		treeViewer.collapseToLevel(databaseModel, TreeViewer.ALL_LEVELS);
		treeViewer.refresh();
		treeViewer.expandToLevel(databaseModel, 1);
	}

	public void expandTableModel(TableModel tableModel) {
		ConnectionContentProvider.getInstance().expandTableModel(tableModel, false);
		treeViewer.collapseToLevel(tableModel, TreeViewer.ALL_LEVELS);
		treeViewer.refresh();
		treeViewer.expandToLevel(tableModel, 1);
	}

	public void refreshSelectedModel() {
		Model model = getSelectedModel();
		ConnectionContentProvider.getInstance().refreshModel(model);
		treeViewer.collapseToLevel(model, 1);
		treeViewer.refresh();
		treeViewer.expandToLevel(model, 1);
	}

	/**
	 * Insert the method's description here.
	 * @see ViewPart#setFocus
	 */
	public void setFocus() {
	}

	/**
	 * @param model
	 * @param b
	 */
	public void executeQuery(Model model, boolean newTab) {
		if (model != null && model instanceof TableModel) {
			TableModel tableModel = (TableModel) model;
			//expandTableModel(tableModel);

			Statement stmt = null;
			ResultSet rs = null;
			try {
				Connection con = ConnectionContentProvider.getInstance().getSelectedConnectionModel().getConnection();
				stmt = con.createStatement();

				rs = stmt.executeQuery("SELECT count(*) FROM " + tableModel.getName());
				if (rs.next()) {
					int max = rs.getInt(1);
					if (max > 2000) {
						if (MessageDialog
							.openQuestion(
								getSite().getShell(),
								"Warning",
								"There are " + max + " results, do you want to continue?")) {
							executeQuery("SELECT * FROM " + tableModel.getName(), newTab);
						}
					} else {
						executeQuery("SELECT * FROM " + tableModel.getName(), newTab);
					}
				}
			} catch (SQLException e) {
				MessageDialog.openError(EasySQLPlugin.getShell(), "EasySQL", e.getMessage());
			} finally {
				EasySQLUtils.closeResultSet(rs);
				EasySQLUtils.closeStatement(stmt);
			}
		} else if (model != null && model instanceof ColumnModel) {

			TableModel tableModel = (TableModel) ((ColumnModel) model).getParent();

			Statement stmt = null;
			ResultSet rs = null;
			try {
				Connection con = ConnectionContentProvider.getInstance().getSelectedConnectionModel().getConnection();
				stmt = con.createStatement();

				String selectedColumns = "";
				StructuredSelection selection = (StructuredSelection) treeViewer.getSelection();
				Iterator iter = selection.iterator();
				String firstColumn = null;
				while (iter.hasNext()) {
					selectedColumns += iter.next();
					if (firstColumn == null) {
						firstColumn = selectedColumns;
					}
					if (iter.hasNext()) {
						selectedColumns += ",";
					}
				}

				rs = stmt.executeQuery("SELECT count(*) FROM " + tableModel.getName());
				if (rs.next()) {
					int max = rs.getInt(1);
					if (max > 5000) {
						if (MessageDialog
							.openQuestion(
								getSite().getShell(),
								"Warning",
								"There are " + max + " results, do you want to continue?")) {
							executeQuery(
								"SELECT "
									+ selectedColumns
									+ " FROM "
									+ tableModel.getName()
									+ " ORDER BY "
									+ firstColumn,
								newTab);
						}
					} else {
						executeQuery(
							"SELECT " + selectedColumns + " FROM " + tableModel.getName() + " ORDER BY " + firstColumn,
							newTab);
					}
				}
			} catch (SQLException e) {
				MessageDialog.openError(EasySQLPlugin.getShell(), "EasySQL", e.getMessage());
			} finally {
				EasySQLUtils.closeResultSet(rs);
				EasySQLUtils.closeStatement(stmt);
			}
		} else {
            MessageDialog.openInformation(getSite().getShell(), "EasySQL", "You must select a table!");
			//MessageView.getInstance().addMessage("You must select a table!");
		}
	}

	/**
	 * select count(*)
	 */
	public void executeCountQuery(Model model, boolean newTab) throws SQLException {
		if (model != null && model instanceof TableModel) {
			TableModel tableModel = (TableModel) model;
			//expandTableModel(tableModel);

			executeQuery("SELECT count(*) FROM " + tableModel.getName(), newTab);
		} else {
			MessageView.getInstance().addMessage("You must select a table!");
		}
	}

	public TreeViewer getTreeViewer() {
		return treeViewer;
	}
}