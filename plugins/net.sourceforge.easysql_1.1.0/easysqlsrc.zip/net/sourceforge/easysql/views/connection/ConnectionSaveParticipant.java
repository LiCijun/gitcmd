package net.sourceforge.easysql.views.connection;

import java.io.File;
import java.sql.Connection;

import net.sourceforge.easysql.EasySQLPlugin;

import org.apache.log4j.Logger;
import org.eclipse.core.resources.ISaveContext;
import org.eclipse.core.resources.ISaveParticipant;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.Path;

/**
 * @author jtoth
 */
public class ConnectionSaveParticipant implements ISaveParticipant
{
	private Logger log= Logger.getLogger(ConnectionSaveParticipant.class);

	/**
	 * @see org.eclipse.core.resources.ISaveParticipant#doneSaving(ISaveContext)
	 */
	public void doneSaving(ISaveContext context)
	{
	}

	/**
	 * @see org.eclipse.core.resources.ISaveParticipant#prepareToSave(ISaveContext)
	 */
	public void prepareToSave(ISaveContext context) throws CoreException
	{
	}

	/**
	 * @see org.eclipse.core.resources.ISaveParticipant#rollback(ISaveContext)
	 */
	public void rollback(ISaveContext context)
	{
	}

	/**
	 * @see org.eclipse.core.resources.ISaveParticipant#saving(ISaveContext)
	 */
	public void saving(ISaveContext context) throws CoreException {
		log.info("saving connections...");

        if(context.getKind() == ISaveContext.FULL_SAVE) {
        	log.info("closing jdbc connection...");
			try {
				// Disconnect
				ConnectionModel model = ConnectionContentProvider.getInstance()
						.getSelectedConnectionModel();

				if(model != null) {
					Connection con = model.getConnection();
					if(con != null) {
						con.close();
					}
				}
			}
			catch (Exception e) {
				log.error(e, e);
			}
		}

        switch ( context.getKind() ) {

            case ISaveContext.FULL_SAVE:
            case ISaveContext.SNAPSHOT:
                if ( ConnectionContentProvider.getInstance().hasChanged() ) {
                    EasySQLPlugin plugin = EasySQLPlugin.getInstance();                    

                    int saveNumber = context.getSaveNumber();

                    log.info("saving connection number: " + saveNumber);

                    String saveFileName = "save" + Integer.toString(saveNumber);
                    File f = plugin.getStateLocation().append(saveFileName).toFile();
                    ConnectionContentProvider.getInstance().save(f);

                    //save again without number
                    f = plugin.getStateLocation().append("save").toFile();
                    ConnectionContentProvider.getInstance().save(f);

                    // map saved file name with common name
                    context.map( new Path("save"), new Path(saveFileName) );            
                    context.needSaveNumber();
                } else {
                	 if(context.getKind() == ISaveContext.FULL_SAVE) {
                	 	log.info("Connection have not changed. Not saving.");
                	 }
                }
            break;
        }
	}

}
