package net.sourceforge.easysql.views.connection;

import net.sourceforge.easysql.EasySQLUtils;

/**
 * @author jtoth
 */
public class ColumnModel extends Model {
	private boolean primaryKey = false;
	private boolean foreignKey = false;
	private TableModel fkTable = null;
	private ColumnModel fkColumn = null;
	private Class javaClass = null;

	private int decimalDigits;
	private boolean nullable;
	private String fkColumnName;

	/**
	 * @return
	 */
	public boolean isPrimaryKey() {
		return primaryKey;
	}

	/**
	 * @param b
	 */
	public void setPrimaryKey(boolean b) {
		primaryKey = b;
		getTable().addPrimaryKey(this);
	}
	/**
	 * @return
	 */
	public int getDecimalDigits() {
		return decimalDigits;
	}

	/**
	 * @return
	 */
	public boolean isNullable() {
		return nullable;
	}

	/**
	 * @param i
	 */
	public void setDecimalDigits(int i) {
		decimalDigits = i;
	}

	/**
	 * @param b
	 */
	public void setNullable(boolean b) {
		nullable = b;
	}

	/**
	 * @return
	 */
	public boolean isForeignKey() {
		return foreignKey;
	}

	/**
	 * @param b
	 */
	public void setForeignKey(boolean b) {
		foreignKey = b;
	}

	/**
	 * @param tableName
	 */
	public void setFKTable(String tableName,String columnName) {
		TableModel table = EasySQLUtils.getTableModelByName(tableName);
		TableModel parentTable = getTable();
		if(!isPK()){
			//One to Many
			table.addOneToMany(this,parentTable);
		} else{
			if(parentTable.getPks().size() > 1) {
				table.addOneToMany(this,parentTable);
			} else {
				//One to One
				table.addOneToOne(this,parentTable);
			}
		}
		fkTable = table;

		this.fkColumnName = columnName;
	}

	private TableModel getTable() {
		return (TableModel) getParent();
	}

	/**
	 * @return
	 */
	public TableModel getFkTable() {
		return fkTable;
	}

	/**
	 * @return
	 */
	public ColumnModel getFKKColumn() {
		if(this.fkColumn == null){
			ColumnModel c = this.fkTable.getColumn(this.fkColumnName);
			setFKColumn(c);
		}
		return this.fkColumn;
	}

	/**
	 * @param string
	 */
	public void setFKColumn(ColumnModel c) {
		this.fkColumn = c;
		if(this.fkColumn != null && this.fkColumn.isPK()){
			System.err.println(123);
		}
	}

	/**
	 * @return
	 */
	public Class getJavaClass() {
		return javaClass;
	}

	/**
	 * @param class1
	 */
	public void setJavaClass(Class class1) {
		javaClass = class1;
	}
	
	public boolean isStringClass(){
		return getJavaClass() == String.class;
	}

	public boolean isPK() {
		return isPrimaryKey();
	}

	public boolean isFK() {
		return isForeignKey();
	}
}