package net.sourceforge.easysql.views.connection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author jtoth
 * @author rlecheta
 */
public class TableModel extends Model {

	private boolean expanded;
	private Map oneToMany;
	private Map oneToOne;
	private List pks;

	/**
	 * To check if the table the columns are loaded in memory
	 */
	public void loadColumns() {
		if (!this.expanded) {
			ConnectionContentProvider.getInstance().expandTableModel(this,false);
		}
	}

	public void setExpanded(boolean b) {
		this.expanded = b;		
	}

	public void addOneToMany(ColumnModel column,TableModel table) {
		if(oneToMany == null){
			oneToMany = new HashMap();
		}
		oneToMany.put(column,table);
	}

	public Map getOneToMany() {
		return oneToMany;
	}
	
	public void addOneToOne(ColumnModel column,TableModel table) {
		if(oneToOne == null){
			oneToOne = new HashMap();
		}
		oneToOne.put(column,table);
	}

	public Map getOneToOne() {
		return oneToOne;
	}

	/**
	 * Convenience method
	 * 
	 * @param name
	 * @return
	 */
	public ColumnModel getColumn(String name) {
		return (ColumnModel) getChildByName(name);
	}

	public void addPrimaryKey(ColumnModel column) {
		if(pks == null){
			pks = new ArrayList(3);
		}
		pks.add(column);
	}
	public List getPks() {
		return pks;
	}
	public List getPrimaryKeys() {
		return pks;
	}
}