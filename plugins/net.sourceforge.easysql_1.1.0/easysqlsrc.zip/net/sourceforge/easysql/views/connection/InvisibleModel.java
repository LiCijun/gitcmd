package net.sourceforge.easysql.views.connection;

/**
 * @author jtoth
 */
public class InvisibleModel extends Model {

    InvisibleModel() {
        super();
    }

    InvisibleModel(String s) {
        super(s);
    }    

}
