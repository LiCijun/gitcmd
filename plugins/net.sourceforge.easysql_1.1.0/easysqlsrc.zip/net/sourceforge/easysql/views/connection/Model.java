package net.sourceforge.easysql.views.connection;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.eclipse.core.runtime.IAdaptable;

public class Model implements IAdaptable {
	protected String name;
	protected List children;
	protected Model parent;
	protected int type;
	protected String typeName;
	protected int size;

	public Model() {
		children = new ArrayList();
	}

	public Model(String name) {
		this();
		this.name = name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public String getCapName() {
		return StringUtils.capitalise(getName());
	}

	public String getUncapName() {
		return StringUtils.uncapitalise(getName());
	}

	public String getJavaName() {
		return StringUtils.capitalise(getName().toLowerCase());
	}

	public void setParent(Model parent) {
		this.parent = parent;
	}

	public Model getParent() {
		return parent;
	}

	public Object getAdapter(Class key) {
		return null;
	}

	public void addChild(Model child) {
		children.add(child);
		child.setParent(this);
	}

	public void removeChild(Model child) {
		children.remove(child);
		child.setParent(null);
	}

	public void removeChildren() {
		children = new ArrayList();
	}

	public Model[] getChildren() {
		return (Model[]) children.toArray(new Model[children.size()]);
	}

	public Model getChildByName(String name) {
		Model[] children = getChildren();
		for (int i = 0; i < children.length; i++) {
			if(children[i].getName().equalsIgnoreCase(name)){
				return children[i];
			}
		}
		return null;
	}

	public List getChildrenList() {
		return children;
	}

	public boolean hasChildren() {
		return children.size() > 0;
	}

	public String toString() {
		return getName();
	}

	public int hashCode() {
		return getName().hashCode();
	}

	/**
	 * Returns the size.
	 * @return int
	 */
	public int getSize() {
		return size;
	}

	/**
	 * Returns the type.
	 * @return int
	 */
	public int getType() {
		return type;
	}

	/**
	 * Returns the typeName.
	 * @return String
	 */
	public String getTypeName() {
		return typeName;
	}

	/**
	 * Sets the size.
	 * @param size The size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}

	/**
	 * Sets the type.
	 * @param type The type to set
	 */
	public void setType(int type) {
		this.type = type;
	}

	/**
	 * Sets the typeName.
	 * @param typeName The typeName to set
	 */
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

}
