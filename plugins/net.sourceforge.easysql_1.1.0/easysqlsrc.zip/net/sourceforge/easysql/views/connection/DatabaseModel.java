package net.sourceforge.easysql.views.connection;

/**
 * @author jtoth
 */
public class DatabaseModel extends Model {
	
	private boolean catalog = false;
	private String schema = null;
	
	/**
	 * Returns true if the Database supports catalogs
	 * @return
	 */
	public boolean hasCatalog() {
		return catalog;
	}

	/**
	 * @param b
	 */
	public void setCatalog(boolean b) {
		catalog = b;
	}


	/**
	 * Returns the database SCHEMA.
	 * Returns null if don�t have SCHEMA
	 * @return
	 */
	public String getSchema() {
		return schema;
	}

	/**
	 * @param string
	 */
	public void setSchema(String string) {
		schema = string;
	}

}
