package net.sourceforge.easysql.views.connection;

import java.sql.Connection;

/**
 * @author jtoth
 * @author Ricardo Lecheta
 */
public class ConnectionModel extends Model {

	public static String NAME_NODE = "NAME";
	public static String SCHEMA_NODE = "SCHEMA";
	public static String USERNAME_NODE = "USERNAME";
	public static String PASSWORD_NODE = "PASSWORD";
	public static String URL_NODE = "URL";
	public static String DRIVER_NODE = "DRIVER";
	public static String DRIVER_JAR_NODE = "DRIVER_JAR";
    public static String SHOW_TABLES = "SHOW_TABLES";
    public static String SHOW_VIEWS = "SHOW_VIEWS";

	String name = "";
	String username = "";
	String password = "";
	String url = "";
	String driver = "";
	String driverJar = "";
	String schema = "";
    String showTables = "";
    String showViews = "";

	Connection conn = null;

	/**
	 * Returns the driver.
	 * @return String
	 */
	public String getDriver() {
		return driver;
	}

	/**
	 * Returns the driverJar.
	 * @return String
	 */
	public String getDriverJar() {
		return driverJar;
	}

	/**
	 * Returns the name.
	 * @return String
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the password.
	 * @return String
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Returns the url.
	 * @return String
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * Returns the username.
	 * @return String
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * Sets the driver.
	 * @param driver The driver to set
	 */
	public void setDriver(String driver) {
		this.driver = driver;
	}

	/**
	 * Sets the driverJar.
	 * @param driverJar The driverJar to set
	 */
	public void setDriverJar(String driverJar) {
		this.driverJar = driverJar;
	}

	/**
	 * Sets the name.
	 * @param name The name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Sets the password.
	 * @param password The password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Sets the url.
	 * @param url The url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * Sets the username.
	 * @param username The username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * Returns the con.
	 * @return Connection
	 */
	public Connection getConnection() {
		return conn;
	}

	/**
	 * Sets the con.
	 * @param con The con to set
	 */
	public void setConnection(Connection con) {
		this.conn = con;
	}

	/**
	 * The user should write "null" to force the Plugin to send a null value.
	 * If the user let the field empty, the plugin will use a empty String, ex: ("").
	 * 
	 * @return The Schema used by the JDBC Driver
	 */
	public String getSchema() {
		if(schema != null && schema.equals("null")) {
			//Sorry for this dummy implementation, but this is the way to be aware
			//of the compatibility with others databases. Only Sybase have problems
			//if the schema is "", so it have to be always null.
			return null;
		}
		return schema;
	}

	public String getRealSchema() {
		return schema;
	}

	public void setSchema(String string) {
		schema = string;
	}
    
	public String getShowTables() {
		return showTables;
	}

	public void setShowTables(String showTables) {
		this.showTables = showTables;
	}

	public String getShowViews() {
		return showViews;
	}

	public void setShowViews(String showViews) {
		this.showViews = showViews;
	}
}
