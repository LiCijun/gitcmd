package net.sourceforge.easysql.views.connection;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Driver;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import net.sourceforge.easysql.EasySQLPlugin;
import net.sourceforge.easysql.EasySQLUtils;
import net.sourceforge.easysql.editors.SQLEditor;
import net.sourceforge.easysql.editors.sql.SQLEditorInput;
import net.sourceforge.easysql.editors.sql.SQLParser;
import net.sourceforge.easysql.views.ConnectionView;
import net.sourceforge.easysql.views.MessageView;
import net.sourceforge.easysql.views.ResultView;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/**
 * @author jtoth
 */
public class ConnectionContentProvider implements ITreeContentProvider {
	private static Logger log = Logger.getLogger(ConnectionContentProvider.class);

	private static Object SEMAPHORE = new Object();
	private static ConnectionContentProvider instance;

	private static boolean hasChanged = false;

	public static InvisibleModel invisibleRootModel = new InvisibleModel("EASYSQL");
	private static Hashtable driverCache = new Hashtable();

	private static DatabaseModel selectedDatabaseModel;
	private static ConnectionModel selectedConnectionModel;

    private static Logger sqlLogger = Logger.getLogger("sqlLogger");

	/**
	 * The constructor.
	 */
	public ConnectionContentProvider() {
		// This should be synchronized or something
		if (instance == null) {
			instance = this;
		}
	}

	// Always returns the first created instance of this class
	public static ConnectionContentProvider getInstance() {
		synchronized (SEMAPHORE) {
			if (instance == null) {
				instance = new ConnectionContentProvider();
			}
		}
		return instance;
	}

	public Object[] getElements(Object parent) {
		return getChildren(parent);
	}

	public Object getParent(Object child) {
		if (child instanceof Model) {
			return ((Model) child).getParent();
		}
		return null;
	}

	// argument invisible root?
	public ConnectionModel[] getConnections() {
		List children = invisibleRootModel.getChildrenList();
		ConnectionModel[] connectionModels = new ConnectionModel[children.size()];
		children.toArray(connectionModels);

		return connectionModels;
	}

	public InvisibleModel getInvisibleRootModel(Model model) {
		Model[] children = model.getChildren();
		if (children.length == 1 && (children[0] instanceof InvisibleModel)) {
			InvisibleModel irm = (InvisibleModel) children[0];
			return irm;
		}
		return null;
	}

	public ConnectionModel getParentConnectionModel(Model model) {
		while (!(model instanceof ConnectionModel)) {
			model = getParentConnectionModel(model.getParent());
		}
		return (ConnectionModel) model;
	}

	public DatabaseModel getDatabaseModel(Model model) {
		while (!(model instanceof DatabaseModel)) {
			model = getDatabaseModel(model.getParent());
		}
		return (DatabaseModel) model;
	}

	public Object[] getChildren(Object parent) {
		if (parent instanceof Model) {
			return ((Model) parent).getChildren();
		}
		return new Object[0];
	}

	public boolean hasChildren(Object parent) {
		if (parent instanceof Model)
			return ((Model) parent).hasChildren();
		return false;
	}

	/**
	 * @see org.eclipse.jface.viewers.IContentProvider#dispose()
	 */
	public void dispose() {
	}

	/**
	 * @see org.eclipse.jface.viewers.IContentProvider#inputChanged(Viewer, Object, Object)
	 */
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
	}

	/**
	 * Returns the hasChanged.
	 * @return boolean
	 */
	public boolean hasChanged() {
		return hasChanged;
	}

	/**
	 * Sets the hasChanged.
	 * @param hasChanged The hasChanged to set
	 */
	public void setHasChanged(boolean hasChanged) {
		ConnectionContentProvider.hasChanged = hasChanged;
	}

	public Document serializeConnectionModelToXML() {
		Document document = null;
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setIgnoringElementContentWhitespace(true);
			DocumentBuilder db = dbf.newDocumentBuilder();
			document = db.newDocument();
		} catch (Exception e) {
			e.printStackTrace();
		}

		Element rootNode = document.createElement(invisibleRootModel.getName());

		// For each connection
		ConnectionModel[] connectionModels = (ConnectionModel[]) getConnections();

		for (int i = 0; i < connectionModels.length; i++) {
			Element connectionNode = document.createElement(connectionModels[i].getName());

			connectionNode.appendChild(
				createNode(document, ConnectionModel.USERNAME_NODE, connectionModels[i].getUsername()));

			connectionNode.appendChild(
				createNode(document, ConnectionModel.SCHEMA_NODE, connectionModels[i].getRealSchema()));

			connectionNode.appendChild(
				createNode(document, ConnectionModel.PASSWORD_NODE, connectionModels[i].getPassword()));

			connectionNode.appendChild(createNode(document, ConnectionModel.URL_NODE, connectionModels[i].getUrl()));

			connectionNode.appendChild(
				createNode(document, ConnectionModel.DRIVER_NODE, connectionModels[i].getDriver()));

			connectionNode.appendChild(
				createNode(document, ConnectionModel.DRIVER_JAR_NODE, connectionModels[i].getDriverJar()));

            connectionNode.appendChild(
                    createNode(document, ConnectionModel.SHOW_TABLES, connectionModels[i].getShowTables()));

            connectionNode.appendChild(
                    createNode(document, ConnectionModel.SHOW_VIEWS, connectionModels[i].getShowViews()));

			rootNode.appendChild(connectionNode);
		}

		document.appendChild(rootNode);

		return document;
	}

	// XML Helper method
	private Element createNode(Document document, String name, String text) {
		Element childNode = document.createElement(name);
		Text textNode = document.createTextNode(text);
		childNode.appendChild(textNode);
		return childNode;
	}

	/**
	 * Save connections to XML file
	 */
	public void save(File file) {
		try {
			Document document = serializeConnectionModelToXML();
			OutputFormat format = new OutputFormat(document);
			format.setIndenting(true);

			FileWriter fileOutput = new FileWriter(file);
			XMLSerializer serial = new XMLSerializer(fileOutput, format);
			serial.asDOMSerializer(); // As a DOM
			serial.serialize(document);
			fileOutput.close();
		} catch (Throwable e) {
			log.error(e,e);
		}
	}

	/**
	 * Create connection models From Xml
	 */
	public ConnectionModel[] createConnectionModelsFromXml(Document document) {
		ArrayList connectionModelList = new ArrayList();

		Node rootNode = document.getLastChild();
		NodeList connectionNodeList = rootNode.getChildNodes();
		for (int i = 0; i < connectionNodeList.getLength(); i++) {
			Node connectionNode = connectionNodeList.item(i);
			if (connectionNode.getNodeType() != Node.ELEMENT_NODE) {
				continue;
			}

			ConnectionModel connectionModel = new ConnectionModel();
			String connectionName = connectionNode.getNodeName();
			connectionModel.setName(connectionName);

			NodeList dataNodeList = connectionNode.getChildNodes();
			for (int x = 0; x < dataNodeList.getLength(); x++) {
				Node dataNode = dataNodeList.item(x);
				if (dataNode.getNodeType() != Node.ELEMENT_NODE) {
					continue;
				}

				String nodeName = dataNode.getNodeName();
				Node child = dataNode.getFirstChild();
				if (child == null) {
					continue;
				}
				String nodeValue = child.getNodeValue();
				if (nodeName.equals(ConnectionModel.USERNAME_NODE)) {
					connectionModel.setUsername(nodeValue);
				}
				if (nodeName.equals(ConnectionModel.SCHEMA_NODE)) {
					connectionModel.setSchema(nodeValue);
				} else if (nodeName.equals(ConnectionModel.PASSWORD_NODE)) {
					connectionModel.setPassword(nodeValue);
				} else if (nodeName.equals(ConnectionModel.URL_NODE)) {
					connectionModel.setUrl(nodeValue);
				} else if (nodeName.equals(ConnectionModel.DRIVER_NODE)) {
					connectionModel.setDriver(nodeValue);
				} else if (nodeName.equals(ConnectionModel.DRIVER_JAR_NODE)) {
					connectionModel.setDriverJar(nodeValue);
				} else if (nodeName.equals(ConnectionModel.SHOW_TABLES)) {
                    connectionModel.setShowTables(nodeValue);
                } else if (nodeName.equals(ConnectionModel.SHOW_VIEWS)) {
                    connectionModel.setShowViews(nodeValue);
                }
			}
			connectionModelList.add(connectionModel);
		}

		return (ConnectionModel[]) connectionModelList.toArray(new ConnectionModel[connectionModelList.size()]);
	}

	public void load(File file) throws Exception {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setIgnoringElementContentWhitespace(true);
		dbf.setIgnoringComments(true);
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document document = db.parse(file);

		ConnectionModel[] connectionModel = createConnectionModelsFromXml(document);
	
		invisibleRootModel.removeChildren();

		for (int i = 0; i < connectionModel.length; i++) {
			invisibleRootModel.addChild(connectionModel[i]);
		}
	}

	public void connect(ConnectionModel connectionModel) {
		try {
			URL urls[] = new URL[1];

			String driverFile = connectionModel.getDriverJar();
			URLClassLoader loader = (URLClassLoader) driverCache.get(driverFile);

			if (loader == null) {
				urls[0] = new File(driverFile).toURL();
				loader = new URLClassLoader(urls);
				driverCache.put(driverFile, loader);
			}

			Class driverClass = loader.loadClass(connectionModel.getDriver());
			Driver driver = (Driver) driverClass.newInstance();

			Properties props = new Properties();
			props.put("user", connectionModel.getUsername());
			props.put("password", connectionModel.getPassword());

			Connection con = driver.connect(connectionModel.getUrl(), props);
			if (con == null) {
				throw new SQLException("Connection Invalid, please verify URL.");
			}

			connectionModel.setConnection(con);

			// Add Databases        	
			populateConnectionModel(connectionModel);

			// Set selected connection
			setSelectedConnectionModel(connectionModel);
			// Set selected database = null
			setSelectedDatabaseModel(null);

			// Find buffer editor
			IEditorPart bufferEditor = null;
			IEditorReference[] editorRefs = ConnectionView.getInstance().getViewSite().getPage().getEditorReferences();
			for (int i = 0; i < editorRefs.length; i++) {
				IEditorPart editorPart = editorRefs[i].getEditor(false);
				if (editorPart != null && editorPart.getEditorInput() instanceof SQLEditorInput) {
					bufferEditor = editorPart;
					break;
				}
			}

			// If editor exists, setFocus
			if (bufferEditor != null) {
				SQLEditor sqlEditor = (SQLEditor) bufferEditor;
				sqlEditor.setFocus();
			} else {
				// Open new buffer
				//ConnectionView.getInstance().getViewSite().getPage().openEditor(new SQLEditorInput(), SQLEditor.ID);
			}
		} catch (ClassNotFoundException e) {
			String error = "Error loading driver, please check driver jar and driver class.";
			MessageDialog.openError(EasySQLPlugin.getShell(), "Connection Error", error);
			MessageView.getInstance().addMessage(error);
		} catch (Throwable e) {
			String error = e.getMessage();
			MessageDialog.openError(EasySQLPlugin.getShell(), "Connection Error", error);
			MessageView.getInstance().addMessage(e);
		}
	}

	public void disconnect(ConnectionModel connectionModel) {
		try {
			// Disconnect
			Connection con = connectionModel.getConnection();

            if(con!=null) {
                con.close();
            }
		} catch (SQLException e) {
			log.error(e, e);
		}

        connectionModel.setConnection(null);

        // If connectionModel was selected, deselect it
        if (connectionModel.equals(getSelectedConnectionModel())) {
            setSelectedConnectionModel(null);
            setSelectedDatabaseModel(null);
        }

        // Remove children from tree
        Model[] model = connectionModel.getChildren();
        for (int i = 0; i < model.length; i++) {
            connectionModel.removeChild(model[i]);
        }
	}

	public void refreshModel(Model model) {

		if (model == null) {
			return;
		}

		// Remove children from tree
		model.removeChildren();

		if (model instanceof ConnectionModel) {
			ConnectionModel connectionModel = (ConnectionModel) model;
			populateConnectionModel(connectionModel);
		} else if (model instanceof DatabaseModel) {
			DatabaseModel databaseModel = (DatabaseModel) model;
			populateDatabaseModel(databaseModel);
		} else if (model instanceof TableModel) {
			TableModel tableModel = (TableModel) model;
			populateTableModel(tableModel);
		}
	}

	public void executeQuery(SQLEditor editor, boolean newTab) throws SQLException { // Execute selected text
		String sql = editor.getSelectedText();

		// If none selected execute all
		if (sql.equals("")) {
			sql = editor.getText();
		}

		if (sql == null || sql.trim().length() == 0) {
			return;
		}

		executeQuery(sql, newTab);
	}

	public int executeQuery(String query) throws SQLException {
		return executeQuery(query, false);
	}

	/**
	 * Execute all statements in a File.
	 * @param f
	 * @throws IOException
	 * @throws SQLException
	 */
	public void executeQuery(File f) throws IOException, SQLException {
		if (f != null && f.exists()) {
			BufferedReader reader = new BufferedReader(new FileReader(f));
			StringBuffer buffer = new StringBuffer();
            String query = null;
			while ((query = reader.readLine()) != null) {
				buffer.append(query);
                buffer.append("\r\n");
			}
			reader.close();
            executeQuery(buffer.toString(), false);
		} else {
			MessageDialog.openInformation(EasySQLPlugin.getShell(), "", "File not found!");
		}
	}

	/**
	 * @param query - SQL Query to execute 
	 * @param newTab - Open in new tab
	 * @param verbose - Log messages in the Messages View
	 * @return
	 * @throws SQLException
	 */
	public int executeQuery(String query, boolean newTab) throws SQLException {

		int updateRow = 0;

		// SQL Parser
		String[] statements = SQLParser.parseSQL(query);

		// If no statements, don't execute
		if (statements == null || statements.length == 0) {
			return -1;
		}

		Connection con = getInstance().getSelectedConnectionModel().getConnection();

		Statement stmt = null;
		ResultSet rs = null;
		try {

			stmt = con.createStatement();

			boolean flag = false;

			// Execute statements        
			for (int i = 0; i < statements.length; i++) {

				sqlLogger.info(statements[i]);

				// Execute query
				if (statements[i] != null && statements[i].trim().startsWith("@")) {
					File f = new File(statements[i].trim().substring(1));
					if (f.exists()) {
						try {
							// execute all statements in the file. (@c:/temp/statements.txt)
							executeQuery(f);

							MessageDialog.openInformation(EasySQLPlugin.getShell(), "EasySQL", "File executed successfully!");
						} catch (IOException e) {
							MessageDialog.openError(EasySQLPlugin.getShell(), "EasySQL", e.getMessage());
						}
					}
				} else {
					flag = stmt.execute(statements[i]);

					// No ResultSet, display update/insert/delete number of records effected
					if (flag) {
						rs = stmt.getResultSet();

						if(!ResultView.getInstance().isLoaded()){
							EasySQLUtils.showView(ResultView.ID);
						}
						ResultView.getInstance().addResultSet(rs, statements[i], newTab);

					} else {
						int updateCount = stmt.getUpdateCount();
						if (updateCount == -1) {
							break;
						}
						MessageView.getInstance().addMessage(updateCount + " records effected: " + statements[i]);
						updateRow += updateCount;
					}
				}
			}
		} catch (SQLException e) {
			MessageView.getInstance().addMessage(e.getMessage());
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e1) {
				MessageView.getInstance().addMessage(e1.getMessage());
				log.error(e1, e1);
			}
			try {
				if (stmt != null) {
					stmt.close();
				}
			} catch (SQLException e2) {
				MessageView.getInstance().addMessage(e2.getMessage());
				log.error(e2, e2);
			}
		}

		return updateRow;
	}

	public void expandDatabaseModel(DatabaseModel databaseModel, boolean refresh) {
		// If expanded once and no refresh, don't repopulate    
		InvisibleModel irm = getInvisibleRootModel(databaseModel);
		if (irm == null) {
			if (refresh == false) {
				return;
			}
		} else {
			refresh = true;
		}

		if (refresh) {
			databaseModel.removeChildren();
			populateDatabaseModel(databaseModel);
		}
	}

	public void expandTableModel(TableModel tableModel, boolean refresh) {
		// If expanded once and no refresh, don't repopulate    
		InvisibleModel irm = getInvisibleRootModel(tableModel);
		if (irm == null) {
			if (refresh == false) {
				return;
			}
		} else {
			refresh = true;
		}

		if (refresh) {
			tableModel.removeChildren();
			populateTableModel(tableModel);
		}

		tableModel.setExpanded(true);
	}

	/**
	 * Returns the selectedConnectionModel.
	 * @return ConnectionModel
	 */
	public ConnectionModel getSelectedConnectionModel() {
		return selectedConnectionModel;
	}

	/**
	 * Returns the selectedDatabaseModel.
	 * @return DatabaseModel
	 */
	public DatabaseModel getSelectedDatabaseModel() {
		return selectedDatabaseModel;
	}

	/**
	 * Returns the invisibleRootModel.
	 * @return InvisibleRootModel
	 */
	public InvisibleModel getInvisibleRootModel() {
		return invisibleRootModel;
	}

	/**
	 * Sets the selectedConnectionModel.
	 * @param selectedConnectionModel The selectedConnectionModel to set
	 */
	public void setSelectedConnectionModel(ConnectionModel selectedConnectionModel) {
		ConnectionContentProvider.selectedConnectionModel = selectedConnectionModel;
	}

	/**
	 * Sets the selectedDatabaseModel.
	 * @param selectedDatabaseModel The selectedDatabaseModel to set
	 */
	public void setSelectedDatabaseModel(DatabaseModel selectedDatabaseModel) {
		ConnectionContentProvider.selectedDatabaseModel = selectedDatabaseModel;
	}

	public void populateConnectionModel(ConnectionModel connectionModel) {
		try {
			// Add Databases to Connection Model
			ResultSet databases = null;

			DatabaseMetaData dbmd = connectionModel.getConnection().getMetaData();
			databases = dbmd.getCatalogs();

			boolean hasCatalogs = false;

			// All Databases from Connection
			while (databases.next()) {
				// Add Database
				DatabaseModel databaseModel = new DatabaseModel();
				String databaseName = databases.getString(1);
				databaseModel.setName(databaseName);
				databaseModel.setSchema(connectionModel.getSchema());
				databaseModel.setCatalog(true);

				connectionModel.addChild(databaseModel);

				// Add invisible root, just to show [+] expand tree
				databaseModel.addChild(new InvisibleModel("NONE"));

				hasCatalogs = true;
			}

			// don�t have catalogs
			if (!hasCatalogs) {
				DatabaseModel databaseModel = new DatabaseModel();
				databaseModel.setName(connectionModel.getName());
				databaseModel.setSchema(connectionModel.getSchema());
				databaseModel.setCatalog(false);

				connectionModel.addChild(databaseModel);

				// Add invisible root, just to show [+] expand tree
				databaseModel.addChild(new InvisibleModel("NONE"));
			}
		} catch (SQLException e) {
			MessageView.getInstance().addMessage(e.getMessage());
		}
	}

	public void populateDatabaseModel(DatabaseModel databaseModel) {
		try {
			ConnectionModel connectionModel = getParentConnectionModel(databaseModel);
            Connection con = connectionModel.getConnection();
            DatabaseMetaData dbmd = con.getMetaData();

            // Verify if the database has catalogs
            String catalog = databaseModel.hasCatalog() ? databaseModel.getName() : null;

            /** Get Tables **/
			if(StringUtils.equalsIgnoreCase(connectionModel.getShowTables(),"true")) {
				String[] types = { "TABLE" };

				if(databaseModel.getSchema() != null){
					if(databaseModel.getSchema().equals("null")){
						databaseModel.setSchema(null);
					}
				}

				// Get all tables
				ResultSet rsTables = dbmd.getTables(catalog, databaseModel.getSchema(), null, types);

				boolean ok = fillTtables(databaseModel, rsTables);
				if(!ok){
					//TRY in UPPER CASE
					rsTables.close();
					String schema = StringUtils.upperCase(databaseModel.getSchema());
					rsTables = dbmd.getTables(catalog, schema, null, types);
					ok = fillTtables(databaseModel, rsTables);
					if(ok){
						databaseModel.setSchema(schema);
					}
				}
				if(!ok && databaseModel.getSchema() != null && databaseModel.getSchema().trim().equals("?")){
					//TRY with NULL
					rsTables.close();
					rsTables = dbmd.getTables(catalog, null, null, types);
					ok = fillTtables(databaseModel, rsTables);
					if(ok){
						databaseModel.setSchema(null);
					}
				}

				rsTables.close();
			}

            /** Get Views **/
            if(StringUtils.equalsIgnoreCase(connectionModel.getShowViews(),"true")) {
				String[] types = new String[] { "VIEW" };

				// Get all Vies
				ResultSet rsTables = dbmd.getTables(catalog, databaseModel.getSchema(), null, types);

				while (rsTables.next()) {
					ViewModel viewModel = new ViewModel();
					String tableName = rsTables.getString("TABLE_NAME");
					viewModel.setName(tableName);
					databaseModel.addChild(viewModel);

					// Add invisible root, just to show [+] expand tree
					viewModel.addChild(new InvisibleModel("NONE"));
				}

				rsTables.close();
			}

		} catch (SQLException e) {
			MessageView.getInstance().addMessage(e.getMessage());
		}
	}

	/**
	 * Read the ResultSet and fill the TableModel
	 * 
	 * @param databaseModel
	 * @param rsTables
	 * @return
	 * @throws SQLException
	 */
	private boolean  fillTtables(DatabaseModel databaseModel, ResultSet rsTables) throws SQLException {
		boolean ok = false;
		while (rsTables.next()) {
			ok = true;
			TableModel tableModel = new TableModel();
			String tableName = rsTables.getString("TABLE_NAME");
			tableModel.setName(tableName);
			databaseModel.addChild(tableModel);

			// Add invisible root, just to show [+] expand tree
			tableModel.addChild(new InvisibleModel("NONE"));
		}
		return ok;
	}

	public void populateTableModel(TableModel tableModel) {
		try {
			Connection con = getParentConnectionModel(tableModel).getConnection();
			DatabaseModel databaseModel = getDatabaseModel(tableModel);
			DatabaseMetaData dbmd = con.getMetaData();

			// Verify if the database has catalogs
			String catalog = databaseModel.hasCatalog() ? databaseModel.getName() : null;

			ResultSet columns = dbmd.getColumns(catalog, databaseModel.getSchema(), tableModel.getName(), null);

			while (columns.next()) {
				ColumnModel columnModel = new ColumnModel();
				columnModel.setName(columns.getString("COLUMN_NAME"));
				columnModel.setType(columns.getInt("DATA_TYPE"));
				columnModel.setTypeName(columns.getString("TYPE_NAME"));
				columnModel.setJavaClass(EasySQLUtils.getColumnClass(columnModel.getType()));
				columnModel.setSize(columns.getInt("COLUMN_SIZE"));
				columnModel.setDecimalDigits(columns.getInt("DECIMAL_DIGITS"));
				columnModel.setNullable(!("NO".equalsIgnoreCase(columns.getString("IS_NULLABLE"))));

				tableModel.addChild(columnModel);

				// Invisible root node not needed, columns not expandable
				// tableModel.addChild(new InvisibleRootModel("NONE"));
			}

			Model[] columnsChildren = tableModel.getChildren();

			// -- PRIMARY KEYS --
			ResultSet rsPk = dbmd.getPrimaryKeys(catalog, databaseModel.getSchema(), tableModel.getName());
			while (rsPk.next()) {
				String pkName = (String) rsPk.getString("COLUMN_NAME");

				for (int i = 0; i < columnsChildren.length; i++) {
					if (columnsChildren[i].getName().equalsIgnoreCase(pkName)) {
						ColumnModel column = (ColumnModel) columnsChildren[i];
						column.setPrimaryKey(true);
						break;
					}
				}
			}

			// -- Foreign KEYS --
			ResultSet rsFK = dbmd.getImportedKeys(catalog, databaseModel.getSchema(), tableModel.getName());
			while (rsFK.next()) {
				String pkTable = (String) rsFK.getString("PKTABLE_NAME");
				String pkColumn = (String) rsFK.getString("PKCOLUMN_NAME");
				String fkColumn = (String) rsFK.getString("FKCOLUMN_NAME");

				for (int i = 0; i < columnsChildren.length; i++) {
					if (columnsChildren[i].getName().equalsIgnoreCase(fkColumn)) {
						ColumnModel column = (ColumnModel) columnsChildren[i];
						column.setForeignKey(true);
						column.setFKTable(pkTable,pkColumn);
						break;
					}
				}
			}
		} catch (SQLException e) {
			MessageView.getInstance().addMessage(e.getMessage());
		}
	}
}