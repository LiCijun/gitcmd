package net.sourceforge.easysql.views.connection;

import net.sourceforge.easysql.ImageCache;
import net.sourceforge.easysql.views.ConnectionView;

import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

public class ConnectionLabelProvider extends LabelProvider {
	private static Object SEMAPHORE = new Object();
	private static ConnectionLabelProvider instance;

	/**
	 * The constructor.
	 */
	public ConnectionLabelProvider() {
		// This should be synchronized or something
		if (instance == null) {
			instance = this;
		}
	}

	// Always returns the first created instance of this class
	public static ConnectionLabelProvider getInstance() {
		synchronized (SEMAPHORE) {
			if (instance == null) {
				instance = new ConnectionLabelProvider();
			}
		}
		return instance;
	}

	/*
	 * @see ILabelProvider#getImage(Object)
	 */
	public Image getImage(Object model) {
		Image image = null;
		if (model instanceof ConnectionModel) {
			ConnectionModel connectionModel = (ConnectionModel) model;
			if (model == ConnectionView.getInstance().getSelectedConnection()) {
				image = ImageCache.getImage(ImageCache.SELECTED_CONNECTED_ICON);
			}
			else if (connectionModel.getConnection() != null) {
				image = ImageCache.getImage(ImageCache.CONNECTED_ICON);
			}
			else {
				image = ImageCache.getImage(ImageCache.DISCONNECTED_ICON);
			}
		}
		else if (model instanceof DatabaseModel) {
			if (model == ConnectionView.getInstance().getSelectedDatabase()) {
				image = ImageCache.getImage(ImageCache.SELECTED_DATABASE_ICON);
			}
			else {
				image = ImageCache.getImage(ImageCache.DATABASE_ICON);
			}
		}
        else if (model instanceof ViewModel) {
            image = ImageCache.getImage(ImageCache.VIEW_ICON);
        }
		else if (model instanceof TableModel) {
			image = ImageCache.getImage(ImageCache.TABLE_ICON);
		}
		else if (model instanceof ColumnModel) {
			ColumnModel column = (ColumnModel) model;
			if (column.isPrimaryKey()) {
				image = ImageCache.getImage(ImageCache.PK_ICON);
			}
			else if (column.isForeignKey()) {
				image = ImageCache.getImage(ImageCache.FK_ICON);
			}
			else {
				image = ImageCache.getImage(ImageCache.COLUMN_ICON);
			}
		}

		return image;
	}

	/**
	 * @see ILabelProvider#getText(Object)
	 */
	public String getText(Object model) {
		String text = null;
		if (model instanceof ColumnModel) {
			ColumnModel columnModel = (ColumnModel) model;

			int decimalDigits = columnModel.getDecimalDigits() ;
			String size = decimalDigits >0?"("+columnModel.getSize()+","+decimalDigits+")":String.valueOf(columnModel.getSize()); 
			
			String fk = columnModel.getFkTable()!=null?"("+columnModel.getFkTable()+")":"";
			
			text = columnModel.getName() + fk+ " (" + columnModel.getTypeName() + ", " + size  + ((!columnModel.isNullable())?",NOT NULL":"") + ")";
		}
		else {
			text = ((Model) model).getName();
		}

		return text;
	}

	protected RuntimeException unknownElement(Object element) {
		return new RuntimeException("Unknown type of element in tree of type " + element.getClass().getName());
	}

}
