package net.sourceforge.easysql.views.connection;

/**
 * @author Ricardo Lecheta
 */
public class ViewModel extends TableModel {

}
