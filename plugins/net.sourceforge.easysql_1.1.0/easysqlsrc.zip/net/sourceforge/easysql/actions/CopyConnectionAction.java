package net.sourceforge.easysql.actions;

import net.sourceforge.easysql.views.ConnectionView;
import net.sourceforge.easysql.views.connection.ConnectionModel;
import net.sourceforge.easysql.wizards.ConnectionWizard;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

/**
 * @author Ricardo Lecheta
 */
public class CopyConnectionAction extends Action implements IViewActionDelegate {
   IViewPart view;
    /**
     * @see org.eclipse.ui.IViewActionDelegate#init(IViewPart)
     */
    public void init(IViewPart view) {
        this.view = view;
        
    }

    /**
     * @see org.eclipse.ui.IActionDelegate#run(IAction)
     */
    public void run(IAction action) {
        run();
    }
    public void run() {
        ConnectionWizard wizard = new ConnectionWizard();

        ConnectionModel connectionModel = (ConnectionModel) ConnectionView.getInstance().getSelectedModel();
        wizard.init(connectionModel,true);

        WizardDialog dialog = new WizardDialog (view.getSite().getShell(),wizard); 
        dialog.open();
    }

    /**
     * @see org.eclipse.ui.IActionDelegate#selectionChanged(IAction, ISelection)
     */
    public void selectionChanged(IAction action, ISelection selection) {
    }

}