package net.sourceforge.easysql.actions;

import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

import net.sourceforge.easysql.views.ConnectionView;
import net.sourceforge.easysql.views.MessageView;
import net.sourceforge.easysql.views.connection.ColumnModel;
import net.sourceforge.easysql.views.connection.ConnectionContentProvider;
import net.sourceforge.easysql.views.connection.InvisibleModel;
import net.sourceforge.easysql.views.connection.Model;
import net.sourceforge.easysql.views.connection.TableModel;
import net.sourceforge.easysql.vo.JoinVO;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

/**
 * Is possible select more than one table and easysql will
 * do the inner join automatically.
 * 
 * @author Ricardo R. Lecheta
 */
public class JoinAction extends Action implements IViewActionDelegate {

	private IViewPart view = null;

	/**
	 * @see org.eclipse.ui.IViewActionDelegate#init(IViewPart)
	 */
	public void init(IViewPart view) {
		this.view = view;
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		run();
	}

	public void run() {
		StructuredSelection selection = ConnectionView.getInstance().getSelection();

		if (selection == null) {
			MessageDialog.openInformation(
				view.getSite().getShell(),
				"Select a Connection",
				"Please select a connection!");
			return;
		}

		Set tables = new LinkedHashSet();
		Set tablesNames = new LinkedHashSet();
		Set fields = new LinkedHashSet();

		Iterator iter = selection.iterator();
		//System.out.println("--------");
		while (iter.hasNext()) {
			Object o = iter.next();

			if (o instanceof TableModel) {
				//System.out.println("Table: " + o);
				TableModel table = (TableModel) o;

				tables.add(table);
				tablesNames.add(table.getName());
				Model[] columns = table.getChildren();
				for (int i = 0; i < columns.length; i++) {
					fields.add(table.getName() + "." + columns[i].getName());
				}
			} else if (o instanceof ColumnModel) {
				//System.out.println("Column: " + o);
				ColumnModel column = (ColumnModel) o;
				TableModel tableParent = (TableModel) column.getParent();
				//System.out.println("   Parent: " + tableParent);
				tables.add(tableParent);
				tablesNames.add(tableParent.getName());
				fields.add(tableParent.getName() + "." + column.getName());
			}
		}

		Set joinsVO = getJoins(tables, tablesNames);

		if(joinsVO.size()==0) {
			MessageDialog.openWarning(view.getSite().getShell(),"","Foreign Keys not found!");
			return;
		}

		/** JOIN **/
		Set joins = new HashSet();
		Iterator iterator = joinsVO.iterator();
		while (iterator.hasNext()) {
			JoinVO join = (JoinVO) iterator.next();

			joins.add(join.toString());

		}

		StringBuffer query = createQuery(tables, fields, joins);

		executeSQL(query);
	}

	/**
	 * Get the JOIN statement
	 * 
	 * @param tables
	 * @return
	 */
	public Set getJoins(Set tables) {
		Set tablesNames = new LinkedHashSet();
		Iterator iter = tables.iterator();
		while (iter.hasNext()) {
			TableModel table = (TableModel) iter.next();
			tablesNames.add(table.getName());
		}
		return getJoins(tables,tablesNames);
	}

	/**
	 * Get the JOIN statement
	 * 
	 * @param tables
	 * @param tablesNames
	 * @return
	 */
	public Set getJoins(Set tables, Set tablesNames) {
		Set joins = new LinkedHashSet();

		Iterator iter = tables.iterator();
		while (iter.hasNext()) {
			TableModel table = (TableModel) iter.next();
			// System.out.println(table);
			Model[] columns = table.getChildren();

            if(columns != null && columns.length > 0 && columns[0] instanceof InvisibleModel) {
                ConnectionContentProvider.getInstance().expandTableModel(table, false);
                columns=table.getChildren();
            }

			for (int i = 0; i < columns.length; i++) {

				ColumnModel column = (ColumnModel) columns[i];
				if (column.isForeignKey()) {
					//System.out.println("fk: " + column.getForeignPKTable() + " - " + column.getForeignPKColumn());
					if (tablesNames.contains(column.getFkTable().getName())) {
						joins.add(new JoinVO(column.getParent().getName(),column.getName(),column.getFkTable().getName(),column.getFKKColumn().getName()));
					}
				}
			}
		}

		return joins;
	}

	private StringBuffer createQuery(Set tables, Set fields, Set joins) {
		StringBuffer query = new StringBuffer("select ");

		createStatement(fields.iterator(), query, ",");

		query.append(" from ");

		createStatement(tables.iterator(), query, ",");

		query.append(" where ");

		createStatement(joins.iterator(), query, " AND ");
		return query;
	}

	private void executeSQL(StringBuffer query) {
		try {
			ConnectionView.getInstance().executeQuery(query.toString(), false);
		} catch (SQLException e) {
			MessageView.getInstance().addMessage(e.getMessage());
			MessageDialog.openError(view.getSite().getShell(), "EasySQL", e.getMessage());
		}
	}

	private void createStatement(Iterator iter, StringBuffer query, String separator) {
		while (iter.hasNext()) {
			Object o = iter.next();
			query.append(o);
			if (iter.hasNext()) {
				query.append(separator);
			}
		}
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}
}
