package net.sourceforge.easysql.actions;

import net.sourceforge.easysql.views.ConnectionView;

import org.apache.log4j.Logger;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PartInitException;

/**
 * @author Ricardo Lecheta
 */
public class OpenConnectionViewAction implements IWorkbenchWindowActionDelegate {

	/**
	 * Logger for this class
	 */
	private static final Logger logger = Logger.getLogger(OpenConnectionViewAction.class);

	/**
	 * The workbench window in which this delegate exists
	 */
	private IWorkbenchWindow window;

	/**
	 * Create a new instance
	 */
	public OpenConnectionViewAction() {
	}

	/**
	 * Initialize the delegate with the window in which it exists.
	 * 
	 * @param window
	 *            the workbench window
	 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate
	 *      #init(org.eclipse.ui.IWorkbenchWindow)
	 */
	public void init(IWorkbenchWindow window) {
		this.window = window;
	}

	/**
	 * Called when the current selection has changed so that the delegate can
	 * update the state of its associated action. Obviously, this method is not
	 * called if the plugin has not been loaded even if the action is visible to
	 * the user as a menu item or toolbar button.
	 * 
	 * @param action
	 *            the action associated with this delegate and that the delegate
	 *            should update as necessary
	 * @param selection
	 *            the new seleciton
	 * @see org.eclipse.ui.IActionDelegate #selectionChanged(
	 *      org.eclipse.jface.action.IAction,
	 *      org.eclipse.jface.viewers.ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}

	/**
	 * Open the favorites view.
	 * 
	 * @param action
	 *            the action from which the user initiated the operation.
	 * @see org.eclipse.ui.IActionDelegate
	 *      #run(org.eclipse.jface.action.IAction)
	 */
	public void run(IAction action) {
		if(window == null)
			return;
		IWorkbenchPage page = window.getActivePage();
		if(page == null)
			return;
		try {
			page.showView(getID());
		}
		catch (PartInitException e) {
			logger.error(e, e);
		}
	}

	/**
	 * @return
	 */
	public String getID() {
		return ConnectionView.ID;
	}

	/**
	 * Cleanup any resources associated with this delegate.
	 * 
	 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate #dispose()
	 */
	public void dispose() {
	}
}