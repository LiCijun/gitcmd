package net.sourceforge.easysql.actions;

import net.sourceforge.easysql.views.ResultView;

/**
 * @author Ricardo Lecheta
 */
public class OpenResultViewAction extends OpenConnectionViewAction {

	/**
	 * @see net.sourceforge.easysql.actions.OpenConnectionViewAction#getID()
	 */
	public String getID() {
		return ResultView.ID;
	}
}
