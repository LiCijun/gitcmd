package net.sourceforge.easysql.actions;


import net.sourceforge.easysql.views.ConnectionView;
import net.sourceforge.easysql.views.connection.ColumnModel;
import net.sourceforge.easysql.views.connection.Model;
import net.sourceforge.easysql.views.connection.TableModel;
import net.sourceforge.easysql.wizards.InsertWizard;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

/**
 * @author Ricardo R. Lecheta
 */
public class InsertAction
	extends Action
	implements IViewActionDelegate {

	/**
	 * @param string
	 */
	public InsertAction() {}

	private IViewPart view;

	/**
	 * @see org.eclipse.ui.IViewActionDelegate#init(IViewPart)
	 */
	public void init(IViewPart view) {
		this.view = view;
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		run();
	}
	public void run() {
        Model model = ConnectionView.getInstance().getSelectedModel();

		if(model instanceof TableModel || model instanceof ColumnModel) {
			InsertWizard wizard = new InsertWizard(model);

			WizardDialog dialog = new WizardDialog(view.getSite().getShell(), wizard);
			dialog.open();
		}
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}
}
