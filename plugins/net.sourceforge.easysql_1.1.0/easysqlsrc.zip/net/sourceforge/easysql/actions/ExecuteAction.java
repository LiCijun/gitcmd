package net.sourceforge.easysql.actions;

import java.sql.SQLException;

import net.sourceforge.easysql.editors.SQLEditor;
import net.sourceforge.easysql.views.ConnectionView;
import net.sourceforge.easysql.views.MessageView;
import net.sourceforge.easysql.views.connection.ConnectionModel;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;

/**
 * @author Ricardo R. Lecheta
 *
 */
public class ExecuteAction implements IWorkbenchWindowActionDelegate {
	public final static String ID = "net.sourceforge.easysql.actions.ExecuteAction";
	IWorkbenchWindow window;

	/**
	 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#dispose()
	 */
	public void dispose() {
	}

	/**
	 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#init(IWorkbenchWindow)
	 */
	public void init(IWorkbenchWindow window) {
		this.window = window;
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		execute(false);
	}

	public void execute(final boolean newTab) {
		ConnectionModel connectionModel = ConnectionView.getInstance().getSelectedConnection();

		if (connectionModel == null) {
			//MessageView.getInstance().addMessage("Please select a connection.");
			MessageDialog.openWarning(window.getShell(), "", "You must select a connection!");
			return;
		}

		final SQLEditor editor = (SQLEditor) window.getActivePage().getActiveEditor();

		if (editor == null) {
			MessageView.getInstance().addMessage("No active editor");
			return;
		}

//		this.window.getShell().getDisplay().asyncExec(new Runnable() {
//			public void run() {
				try {
					ConnectionView.getInstance().executeQuery(editor, newTab);
				} catch (SQLException e) {
					MessageDialog.openError(window.getShell(),"EasySQL",e.getMessage());
				}
//			}
//		});
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}
}