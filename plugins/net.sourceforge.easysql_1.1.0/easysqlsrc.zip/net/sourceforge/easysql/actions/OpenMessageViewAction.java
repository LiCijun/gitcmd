package net.sourceforge.easysql.actions;

import net.sourceforge.easysql.views.MessageView;

/**
 * @author Ricardo Lecheta
 */
public class OpenMessageViewAction extends OpenConnectionViewAction {

	/**
	 * @see net.sourceforge.easysql.actions.OpenConnectionViewAction#getID()
	 */
	public String getID() {
		return MessageView.ID;
	}
}
