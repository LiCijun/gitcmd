package net.sourceforge.easysql.actions;

import net.sourceforge.easysql.editors.SQLEditor;
import net.sourceforge.easysql.editors.sql.SQLEditorInput;
import net.sourceforge.easysql.views.ConnectionView;
import net.sourceforge.easysql.views.MessageView;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PartInitException;

/**
 * Insert the type's description here.
 * @see IWorkbenchWindowActionDelegate
 */
public class NewBuffer implements IWorkbenchWindowActionDelegate {
	/**
	 * The constructor.
	 */
	public NewBuffer() {
	}

	/**
	 * Insert the method's description here.
	 * @see IWorkbenchWindowActionDelegate#run
	 */
	public void run(IAction action) {
		try {
			ConnectionView.getInstance().getViewSite().getPage().openEditor(
				new SQLEditorInput(),
				SQLEditor.ID);
		} catch (PartInitException e) {
			e.printStackTrace();
			MessageView.getInstance().addMessage(e.getMessage());
		}
	}

	/**
	 * Insert the method's description here.
	 * @see IWorkbenchWindowActionDelegate#selectionChanged
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}

	/**
	 * Insert the method's description here.
	 * @see IWorkbenchWindowActionDelegate#dispose
	 */
	public void dispose() {
	}

	/**
	 * Insert the method's description here.
	 * @see IWorkbenchWindowActionDelegate#init
	 */
	public void init(IWorkbenchWindow window) {
	}
}
