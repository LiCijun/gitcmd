package net.sourceforge.easysql.actions;

import org.eclipse.jface.action.IAction;

/**
 * @author Ricardo R. Lecheta
 *
 */
public class ExecuteNewTabAction extends ExecuteAction {
	public final static String ID =
		"net.sourceforge.easysql.actions.ExecuteNewTabAction";

	/**
	 * @see org.eclipse.ui.IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		super.execute(true);
	}
}