package net.sourceforge.easysql.actions;

import java.sql.SQLException;

import net.sourceforge.easysql.views.ConnectionView;
import net.sourceforge.easysql.views.connection.ConnectionModel;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

/**
 * "select count(*) from tableName"
 * 
 * @author Ricardo R. Lecheta
 */
public class SelectCountTableAction extends Action implements IViewActionDelegate
{
	private IViewPart view = null;

	/**
	 * @see org.eclipse.ui.IViewActionDelegate#init(IViewPart)
	 */
	public void init(IViewPart view)
	{
		this.view = view;
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#run(IAction)
	 */
	public void run(IAction action)
	{
		run();
	}

	/** 
	 * SELECT count(*) FROM TABLENAME
	 * @see org.eclipse.jface.action.IAction#run()
	 */
	public void run()
	{
		ConnectionModel connectionModel = ConnectionView.getInstance().getSelectedConnection();

		if (connectionModel == null)
		{
			MessageDialog.openInformation(view.getSite().getShell(), "Select a Connection", "Please select a connection!");
			return;
		}

		try {
			ConnectionView.getInstance().executeCountQuery(ConnectionView.getInstance().getSelectedModel(), false);
		} catch (SQLException e) {
			MessageDialog.openError(view.getSite().getShell(),"Error",e.getMessage());
		}
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection)
	{
	}
}
