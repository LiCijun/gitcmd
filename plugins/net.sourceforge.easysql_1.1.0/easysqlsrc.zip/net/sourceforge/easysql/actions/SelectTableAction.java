package net.sourceforge.easysql.actions;

import net.sourceforge.easysql.views.ConnectionView;
import net.sourceforge.easysql.views.connection.ConnectionModel;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

/**
 * Execute the "select * from tableName" Statement and show the results
 * int the "Results View"
 * 
 * @author Ricardo R. Lecheta
 */
public class SelectTableAction extends Action implements IViewActionDelegate
{
	private IViewPart view = null;

	/**
	 * @see org.eclipse.ui.IViewActionDelegate#init(IViewPart)
	 */
	public void init(IViewPart view)
	{
		this.view = view;
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#run(IAction)
	 */
	public void run(IAction action)
	{
		run();
	}

	/** 
	 * SELECT * FROM TABLENAME
	 * @see org.eclipse.jface.action.IAction#run()
	 */
	public void run()
	{
		ConnectionModel connectionModel = ConnectionView.getInstance().getSelectedConnection();

		if (connectionModel == null)
		{
			MessageDialog.openInformation(view.getSite().getShell(), "EasySQL", "Please select a connection!");
			return;
		}

		ConnectionView.getInstance().executeQuery(ConnectionView.getInstance().getSelectedModel(), false);
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection)
	{
	}
}
