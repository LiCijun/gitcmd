package net.sourceforge.easysql.actions;

import java.io.File;

import net.sourceforge.easysql.views.ConnectionView;
import net.sourceforge.easysql.views.connection.ConnectionContentProvider;

import org.apache.log4j.Logger;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

/**
 * @author Ricardo Lecheta
 */
public class ExecFileAction extends Action implements IViewActionDelegate {
    IViewPart view;
   
    /**
     * @see org.eclipse.ui.IViewActionDelegate#init(IViewPart)
     */
    public void init(IViewPart view) {
        this.view = view;
    }

    /**
     * @see org.eclipse.ui.IActionDelegate#run(IAction)
     */
    public void run(IAction action) {
        run();
    }

    public void run() {
        FileDialog d = new FileDialog(view.getSite().getShell());
        String path = d.open();
        try {
            if(path != null) {
				File f = new File(path);
				ConnectionContentProvider.getInstance().executeQuery(f);
                MessageDialog.openInformation(view.getSite().getShell(), "EasySQL", "File executed successfully!");
			}
        }
        catch (Exception e) {
            MessageDialog.openInformation(view.getSite().getShell(), "EasySQL", e.getMessage());
            Logger.getLogger(ExecFileAction.class).error(e,e);
        }
        ConnectionView.getInstance().changedConnection();
    }

    /**
     * @see org.eclipse.ui.IActionDelegate#selectionChanged(IAction, ISelection)
     */
    public void selectionChanged(IAction action, ISelection selection) {
    }
}