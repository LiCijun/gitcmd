package net.sourceforge.easysql;

import java.io.File;

import net.sourceforge.easysql.views.connection.ConnectionContentProvider;
import net.sourceforge.easysql.views.connection.ConnectionSaveParticipant;

import org.apache.log4j.Logger;
import org.osgi.framework.BundleContext;

import org.eclipse.core.resources.ISaveParticipant;
import org.eclipse.core.resources.ISavedState;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * The main plugin class to be used in the desktop.
 */
public class EasySQLPlugin extends AbstractUIPlugin {
	private static EasySQLPlugin instance;

    public static String NEWLINE = System.getProperty("line.separator");
    private static Logger log = Logger.getLogger(EasySQLPlugin.class);

	/**
	 * The constructor.
	 */
	public EasySQLPlugin() {
		super();
		instance = this;
		System.out.println("Start EasySQL at " + new File(".").getAbsolutePath());
	}

	/**
	 * Returns the shared instance.
	 */
	public static EasySQLPlugin getInstance() {
		return instance;
	}

	/**
	 * Returns the workspace instance.
	 */
	public static IWorkspace getWorkspace() {
		return ResourcesPlugin.getWorkspace();
	}

	public static String getPluginName() {
		return "EasySQL";
	}

	/**
	 * This method is called upon plug-in activation
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);

		ISaveParticipant saveParticipant = new ConnectionSaveParticipant();
		ISavedState lastState =
			ResourcesPlugin.getWorkspace().addSaveParticipant(
				this,
				saveParticipant);

		if (lastState == null) {
			return;
		}
        
        //get without number
        File f = getStateLocation().append("save").toFile();

		try {
			ConnectionContentProvider.getInstance().load(f);
		} catch (Exception e) {       
            log.error("Saved connections are corrupt, connections deleted, please add new connections");
		}
	}
	
	/**
	 * This method is called when the plug-in is stopped
	 */
	public void stop(BundleContext context) throws Exception {
		super.stop(context);
		Logger.getLogger(EasySQLPlugin.class).info("stopping easysql");
	}

	/**
	 * @return
	 */
	public static Shell getShell() {
		return getInstance().getWorkbench().getActiveWorkbenchWindow().getShell();
	}
}