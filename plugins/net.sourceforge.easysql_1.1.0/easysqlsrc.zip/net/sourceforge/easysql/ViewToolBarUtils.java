package net.sourceforge.easysql;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IViewSite;

/**
 * Creates a ToolBar in the View
 * 
 * @author Ricardo R. Lecheta
 */
public class ViewToolBarUtils
{
	/**
	 * Creates a ToolBar in the View
	 * ex: ViewToolBarUtils.createMenuAndToolBar(getViewSite(),new Action[]{},new Action[]{});
	 * @param site
	 * @param toolbarAction
	 * @param menuAction
	 */
	public static void createMenuAndToolBar(IViewSite site, Action[] toolbarAction, Action[] menuAction)
	{
		IActionBars bars = site.getActionBars();
		fillToolBar(bars.getToolBarManager(), toolbarAction);
		fillMenu(bars.getMenuManager(), menuAction);
	}

	private static void fillToolBar(IToolBarManager manager, Action[] toolbarAction)
	{
		for (int i = 0; i < toolbarAction.length; i++)
		{
			manager.add(toolbarAction[i]);
		}
	}

	private static void fillMenu(IMenuManager manager, Action[] menuAction)
	{
		for (int i = 0; i < menuAction.length; i++)
		{
			manager.add(menuAction[i]);

			if (i < menuAction.length - 1)
			{
				manager.add(new Separator());
			}
		}
	}
}
