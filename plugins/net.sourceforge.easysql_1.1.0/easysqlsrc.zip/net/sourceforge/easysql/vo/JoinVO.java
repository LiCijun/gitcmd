package net.sourceforge.easysql.vo;

/**
 * Value Object (see JoinAction)
 * 
 * @author rlecheta
 * 
 */
public class JoinVO {

	private final String table;
	private final String fkColumn;
	private final String referencedTable;
	private final String referencedPKColumn;

	public JoinVO(String table, String fkColumn, String referencedTable, String referencedPKColumn) {
		this.table = table;
		this.fkColumn = fkColumn;
		this.referencedTable = referencedTable;
		this.referencedPKColumn = referencedPKColumn;
	}

	public String getFkColumn() {
		return fkColumn;
	}

	public String getReferencedPKColumn() {
		return referencedPKColumn;
	}

	public String getReferencedTable() {
		return referencedTable;
	}

	public String getTable() {
		return table;
	}

	/**
	 * Table1.FK_COLUMN = Table2.PK_COLUMN
	 * 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return getTable()
		+ "."
		+ getFkColumn()
		+ "="
		+ getReferencedTable()
		+ "."
		+ getReferencedPKColumn();
	}
}