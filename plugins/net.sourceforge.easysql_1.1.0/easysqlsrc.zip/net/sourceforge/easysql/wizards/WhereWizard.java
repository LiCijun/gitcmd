package net.sourceforge.easysql.wizards;

import java.io.IOException;

import net.sourceforge.easysql.views.MessageView;
import net.sourceforge.easysql.views.connection.ColumnModel;
import net.sourceforge.easysql.views.connection.ConnectionContentProvider;
import net.sourceforge.easysql.views.connection.Model;

import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/**
 * @author Ricardo Lecheta
 */
public class WhereWizard extends TableColumnWizard {

	private Logger log = Logger.getLogger(ExportWizard.class);

	private WherePage insertPage;

	public static final String itens[] = { "=", "<", ">","<=",">=", "<>"," like "," not like "," is "," is not "," in "," not in "," not " };

	/**
	 * @param model
	 */
	public WhereWizard(Model model) {
		super(model);
		setWindowTitle("Query Wizard");
	}

	public boolean performFinish() {
		try {
			return insertPage.performFinish();
		}
		catch (Exception e) {
			MessageDialog.openError(getContainer().getShell(), "Exception", e.getMessage());
		}
		return false;
	}

	public void addPages() {
		insertPage = new WherePage("Query");
		addPage(insertPage);
	}

	class WherePage extends WizardPage {
		private Text[] texts = null;
		private Combo[] conditions = null;

		public WherePage(String pageName) {
			super(pageName);
		}

		public void createControl(Composite parent) {
			Composite container = new Composite(parent, SWT.NULL);
			GridLayout gridLayout = new GridLayout();
			gridLayout.numColumns = 3;
			container.setLayout(gridLayout);

			GridData data = null;

			texts = new Text[columns.length];
			conditions = new Combo[columns.length];

			for (int i = 0; i < columns.length; i++) {
				ColumnModel column = (ColumnModel) columns[i];
				//if (!(column.is)) {
				new Label(container, SWT.PUSH).setText(column.getName());

				texts[i] = new Text(container, SWT.BORDER);
				conditions[i] = new Combo(container, SWT.NONE | SWT.Deactivate);
				conditions[i].setItems(itens);
				conditions[i].setText("=");

				data = new GridData();
				data.widthHint = 150;
				texts[i].setLayoutData(data);
				//} else // autoIncrement
				//	texts[i] = null;
			}

			setControl(container);
			setPageComplete(true);
		}

		public boolean performFinish() throws IOException {
			StringBuffer query = new StringBuffer("SELECT * FROM " + tableModel.getName());

			boolean validColumnFound = false;

			for (int i = 0; i < texts.length; i++) {
				String text = texts[i].getText();

				if(text != null && text.trim().length() > 0) {

					//first time
					if(!validColumnFound) {
						query.append(" WHERE ");
					}
					else {
						query.append(" AND ");
					}

					query.append(columns[i].getName() + conditions[i].getText());

					ColumnModel column = (ColumnModel) columns[i];
					if(column.isStringClass()) {
						query.append("'" + text + "'");
					}
					else {
						query.append(text);
					}

					validColumnFound = true;
				}

			}

			String whereQuery = query.toString();

			try {
				MessageView.getInstance().addMessage(whereQuery);
				ConnectionContentProvider.getInstance().executeQuery(whereQuery);
			}
			catch (Exception e) {
				MessageView.getInstance().addMessage(e.getMessage());
				log.error(e, e);
				//lError.setText(e.getMessage());
				MessageDialog.openError(getShell(), "Error", e.getMessage());
			}

			return false;
		}
	}
}