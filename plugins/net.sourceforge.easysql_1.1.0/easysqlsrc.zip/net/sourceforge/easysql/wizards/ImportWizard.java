package net.sourceforge.easysql.wizards;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

import net.sourceforge.easysql.EasySQLPlugin;
import net.sourceforge.easysql.editors.SQLEditor;
import net.sourceforge.easysql.editors.sql.SQLEditorInput;
import net.sourceforge.easysql.views.ConnectionView;
import net.sourceforge.easysql.views.MessageView;
import net.sourceforge.easysql.views.connection.ColumnModel;
import net.sourceforge.easysql.views.connection.Model;
import net.sourceforge.easysql.views.connection.TableModel;

import org.apache.log4j.Logger;
import org.eclipse.core.resources.IStorage;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PartInitException;

public class ImportWizard extends Wizard {
	private Logger log = Logger.getLogger(ImportWizard.class);
	ImportPage1 importPage1;
    ImportPage2 importPage2;

    boolean includeFileHeader;
    String separator;
    File file;

    boolean canFinish = false;

	public void addPages() {
		importPage1 = new ImportPage1("Import Data");
        importPage2 = new ImportPage2("Import Data");
		addPage(importPage1);
        addPage(importPage2);        
        
	}

    public boolean canFinish() {
        return canFinish;
    }

    public boolean performFinish() {
        return importPage2.performFinish();
    }

    class ImportPage1 extends WizardPage {
        Button includeFileHeaderButton;
        Text separatorText;        
        Text filenameText;     
    	FileDialog dialog;
       
    	public ImportPage1(String pageName) {
    		super(pageName);
    	}
    
        public IWizardPage getNextPage() {          
            includeFileHeader = includeFileHeaderButton.getSelection();

            // Don't trim separator or filename
            separator = separatorText.getText();
            String filename = filenameText.getText();            

            // convert "\t" to tab
            if (separator.equals("\\t")) {
                separator = "\t";
            }

            // Validate Data
            file = new File(filename);
            
            // If does not exist, error
            if (!file.exists()) {
                MessageDialog.openError(
                    getShell(),
                    "Required Fields",
                    "File does not exist");
                return this;                
            }

            importPage2.refreshControl();           
            return super.getNextPage();
        }
       
    	public void createControl(Composite parent) {            
            Composite container = new Composite(parent, SWT.NULL);
            container.setLayout(new GridLayout(1, false));

            Composite subContainer = new Composite(container, SWT.NULL);
            subContainer.setLayout(new GridLayout(2, false));

            // Include Column Names Checkbox
			includeFileHeaderButton =
				new Button(subContainer , SWT.CHECK | SWT.BORDER | SWT.RIGHT);
			includeFileHeaderButton.setSelection(true);
            includeFileHeaderButton.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_END));

            Label label = new Label(subContainer , SWT.LEFT);
            label.setText(" First line of file are column names");

            // separatorText
            separatorText = new Text(subContainer , SWT.BORDER | SWT.SINGLE);
            separatorText.setText("\\t");
            separatorText.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_END));
            separatorText.setSize(4, 0);
            label = new Label(subContainer , SWT.NULL);
            label.setText(" Field separator (\\t for tab)");

            Composite subContainer2 = new Composite(container, SWT.NULL);
            subContainer2.setLayout(new GridLayout(2, false));
            subContainer2.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
                        
            // Export filenameText   
    		filenameText = new Text(subContainer2, SWT.BORDER | SWT.SINGLE);
    		filenameText.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
    
            dialog = new FileDialog(getContainer().getShell(), SWT.OPEN);    
        
    		Button button = new Button(subContainer2, SWT.PUSH);
    		button.setText("Browse...");
    
    		button.addSelectionListener(new SelectionListener() {
    			public void widgetDefaultSelected(SelectionEvent e) {
    			}
    			public void widgetSelected(SelectionEvent e) {
    				String filename = dialog.open();
    				if (filename != null) {
    					filenameText.setText(filename);
    				}
    			}
    		});

            setControl(container);   
    		setPageComplete(true);
    	}
       
    	public boolean canFlipToNextPage() {
            return true;           
    	}
    
    }

    class ImportPage2 extends WizardPage {
        Button executeBtn;
        Button generateBtn;        
    
        ArrayList fileCombos = new ArrayList();
        ArrayList tableCombos = new ArrayList();
    
        ArrayList rows = new ArrayList();
    
        TableModel tableModel;
        BufferedReader fileReader;
    
        boolean validatePage = false;
        Composite bottomContainer;
        int[] columnType;
   
        public ImportPage2(String pageName) {
            super(pageName);
        }

        public void refreshControl() {
            // Read first line
            int tokens = 0;
            StringTokenizer st = null;
            try {
                fileReader = new BufferedReader(new FileReader(file));
                st = new StringTokenizer(fileReader.readLine(), separator);
            } catch (FileNotFoundException e) {
                MessageView.getInstance().addMessage(e);
            } catch (IOException e) {
                MessageView.getInstance().addMessage(e);
            }

            ArrayList row = new ArrayList();
            while (st.hasMoreTokens()) {
                String token = st.nextToken();
                row.add(tokens, token);
                tokens++;                
            }

            rows.add(0, row);

            String[] fileColumns = new String[tokens];
            row.toArray(fileColumns);

            // Get columns
            tableModel = (TableModel) ConnectionView.getInstance().getSelectedModel();
            Model[] children = tableModel.getChildren();           
            
            String[] tableColumns = new String[children.length+1];
            tableColumns[0] = "[None]";                    
            for (int i=1; i<tableColumns.length; i++) {
                tableColumns[i] = children[i-1].getName();
            }
            
            // Get types
            columnType = new int[children.length];
            for (int i=0; i<children.length; i++) {
                ColumnModel columnModel = (ColumnModel) children[i];
                columnType[i] = columnModel.getType();                            
            }
            
            for (int i=0; i<tokens; i++) {
                Combo fileCmb = new Combo(bottomContainer, SWT.DROP_DOWN | SWT.READ_ONLY);
                fileCmb.setItems(fileColumns);
                fileCmb.select(i);
                fileCombos.add(fileCmb);
                
                Combo tableCmb = new Combo(bottomContainer, SWT.DROP_DOWN | SWT.READ_ONLY);
                tableCmb.setItems(tableColumns);
                tableCombos.add(tableCmb);                
                for (int x=0; x<tableColumns.length; x++) {
                    if (tableColumns[x].equals( fileCmb.getItem(i) )) {
                        tableCmb.select(x);
                    }
                }
            }
            
//            bottomContainer.redraw();
            bottomContainer.pack(false);                     
        }

        public void createControl(Composite parent) {                    
            Composite container = new Composite(parent, SWT.NULL);
            container.setLayout(new GridLayout(1, false));

            // Top
            Composite topContainer = new Composite(container, SWT.NULL);
            topContainer.setLayout(new GridLayout(2, true));
            topContainer.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

            Label label = new Label(topContainer, SWT.LEFT);
            label.setText("File Fields");

            Label label2 = new Label(topContainer, SWT.LEFT);
            label2.setText("Table Fields");            

            // Middle
            ScrolledComposite s_bottomContainer = new ScrolledComposite(container, SWT.V_SCROLL | SWT.BORDER);
            s_bottomContainer.setLayout(new GridLayout(2, true));
            s_bottomContainer.setLayoutData(new GridData(GridData.FILL_BOTH));
                
            bottomContainer = new Composite(s_bottomContainer, SWT.NONE);
            bottomContainer.setLayout(new GridLayout(2, true));
            bottomContainer.setLayoutData(new GridData(GridData.FILL_BOTH));            
            s_bottomContainer.setContent(bottomContainer);

//            // Bottom
//            Composite bottomContainer = new Composite(container, SWT.NULL);
//            bottomContainer.setLayout(new GridLayout(5, false));
//            bottomContainer.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
//
//            // Options
//            executeBtn =
//                new Button(bottomContainer, SWT.CHECK | SWT.BORDER | SWT.LEFT);
//            executeBtn.setSelection(false);
//            executeBtn.setText("Execute Import");
//
////            Label importLbl = new Label(bottomContainer , SWT.LEFT);
////            label.setText("Execute Import");
//
//            generateBtn =
//                new Button(bottomContainer, SWT.CHECK | SWT.BORDER | SWT.LEFT);
//            generateBtn.setSelection(true);
//            generateBtn.setText("Generate SQL");
//
////            Label generateLbl = new Label(bottomContainer , SWT.LEFT);
////            generateLbl.setText("Generate SQL");
//
//            // Preview
//            Button previewBtn =
//                new Button(bottomContainer, SWT.PUSH | SWT.BORDER | SWT.LEFT);
//            previewBtn.setText("Preview");

            setControl(container);                                             
            setPageComplete(true);     
            canFinish = true;
        }

    public boolean performFinish() {
        // Build INSERT SQL with parameters (?,?,?) for values
        StringBuffer sqlBuffer = new StringBuffer();
        sqlBuffer.append("INSERT INTO ");
        sqlBuffer.append(tableModel.getName());        
        sqlBuffer.append(" (");           
        
        boolean isColumn[] = new boolean[tableCombos.size()];
    	for (int i = 0; i < tableCombos.size(); i++) {
    		Combo tableCmb = (Combo) tableCombos.get(i);
    		if (tableCmb.getSelectionIndex() == 0) {
    			isColumn[i] = false;
    		} else {
    			isColumn[i] = true;
    			sqlBuffer.append(tableCmb.getText());
    		    sqlBuffer.append(", ");
    		}
    	}
     
        // Delete last comma and space
        sqlBuffer.delete(sqlBuffer.length()-2, sqlBuffer.length());       
        
        sqlBuffer.append(") VALUES (");                
        String buf = sqlBuffer.toString();

        final ArrayList statements = new ArrayList();
        // For each line in file create INSERT
		try {
			while ( fileReader.ready() ) {
			    StringBuffer sql = new StringBuffer(buf);
			    StringTokenizer st = new StringTokenizer(fileReader.readLine(), separator);       
			    ArrayList row = new ArrayList();

			    while (st.hasMoreTokens()) {
			        String token = st.nextToken();
                    log.info("TOKEN :: " + token);
                    row.add(token);
			    }
                
                for (int i = 0; i < fileCombos.size(); i++) {
                    Combo fileCmb = (Combo) fileCombos.get(i);
                    
                    String data = (String) row.get(fileCmb.getSelectionIndex());
                    int tableIndex = ((Combo)tableCombos.get(i)).getSelectionIndex();
                    
                    if ( columnType[tableIndex-1] == Types.CHAR || columnType[tableIndex-1] == Types.VARCHAR) {                        
                        sql.append("'");
                        sql.append(data.replaceAll("\"", "\\\""));
                        sql.append("'");                        
                    } else {
                        sql.append(data);
                    }
                    sql.append(", ");
                }                
                
			    sql.delete(sql.length()-2, sql.length());
			    sql.append(")");
			    System.out.println("SQL :: " + sql);
			    statements.add(sql.toString());
			}
		} catch (IOException e) {
            MessageView.getInstance().addMessage(e);
		}
       
        try {
            ConnectionView.getInstance().getViewSite().getPage().openEditor(
                new SQLEditorInput( new IStorage() {
					/**
					 * @see org.eclipse.core.resources.IStorage#getContents()
					 */
					public InputStream getContents() throws CoreException {
                        Iterator it = statements.iterator();
                        String sql = "";
                        
                        while (it.hasNext()) {
                            sql += (String) it.next();
                            sql += ";" + EasySQLPlugin.NEWLINE;
                        }
                        
						return new ByteArrayInputStream(sql.getBytes());
					}

					/**
					 * @see org.eclipse.core.resources.IStorage#getFullPath()
					 */
					public IPath getFullPath() {
						return null;
					}

					/**
					 * @see org.eclipse.core.resources.IStorage#getName()
					 */
					public String getName() {
						return null;
					}

					/**
					 * @see org.eclipse.core.resources.IStorage#isReadOnly()
					 */
					public boolean isReadOnly() {
						return false;
					}

					/**
					 * @see org.eclipse.core.runtime.IAdaptable#getAdapter(Class)
					 */
					public Object getAdapter(Class adapter) {
						return null;
					}
				}),
                SQLEditor.ID);
        } catch (PartInitException e) {
            e.printStackTrace();
            MessageView.getInstance().addMessage(e.getMessage());
        }        

        return true;
    }

    }
    
}


//
//            FileReader fr = null;
//            try {
//                fr = new FileReader(file);
//                // validate consistent number of fields through file
//                StreamTokenizer st = new StreamTokenizer(fr);
//                st.eolIsSignificant(true);
//
//                ArrayList header = null;
//                if (includeFileHeader) {
//                    header = new ArrayList();
//
//                while (st.nextToken() != StreamTokenizer.TT_EOL) { 
//                    st.nextToken();
//                    int type = st.nextToken();
//                    switch (type) {
//                        case StreamTokenizer.TT_WORD:
//                            tokens++;
//                        break;
//                    }
//                }
//
//
//                while (true) { 
//                    int type = st.nextToken();
//                    switch (type) {
//                        case StreamTokenizer.TT_WORD:
//                            tokens++;
//                        break;
//                        case StreamTokenizer.TT_EOL:
//                            
//                            
//                        
//                    
//            } catch (Exception e) {e
//                MessageView.getInstance().addMessage(e);
//            }        
//
//            // Don't worry about casting, 
//            // Import Data wizard is only accessible when TableModel is selected
//            TableModel tableModel = (TableModel) ConnectionView.getInstance().getSelectedModel();

