package net.sourceforge.easysql.wizards;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.sourceforge.easysql.views.ConnectionView;
import net.sourceforge.easysql.views.connection.ColumnModel;
import net.sourceforge.easysql.views.connection.ConnectionContentProvider;
import net.sourceforge.easysql.views.connection.InvisibleModel;
import net.sourceforge.easysql.views.connection.Model;
import net.sourceforge.easysql.views.connection.TableModel;

import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.wizard.Wizard;

/**
 * @author Ricardo Lecheta
 */
public abstract class TableColumnWizard  extends Wizard {
	
	protected TableModel tableModel = null;

	protected Model[] columns = null;

	/**
	 * @param model
	 */
	public TableColumnWizard(Model model) {
		if(model instanceof TableModel) {
			initTableModel((TableModel) model);
		}
		else if(model instanceof ColumnModel) {
			initColumnModel((ColumnModel) model);
		}
	}
	
	/**
	 * @param model
	 */
	private void initTableModel(TableModel tableModel) {

		this.tableModel = tableModel;
        
		this.columns = tableModel.getChildren();
        //expand
        if(columns != null && columns.length > 0 && columns[0] instanceof InvisibleModel) {
            ConnectionContentProvider.getInstance().expandTableModel(tableModel, false);
        }
	}

	/**
	 * @param model
	 */
	private void initColumnModel(ColumnModel columnModel) {

		this.tableModel = (TableModel) columnModel.getParent();

		initSelectedColumns();
	}

	/**
	 * Get the selection
	 */
	private void initSelectedColumns() {

		List selectedColumns = new ArrayList();

		StructuredSelection selection = (StructuredSelection) ConnectionView.getInstance().getTreeViewer().getSelection();
		Iterator iter = selection.iterator();
		while (iter.hasNext()) {
			selectedColumns.add(iter.next());
		}

		if(selectedColumns.size() > 0) {
			this.columns = (ColumnModel[]) selectedColumns.toArray(new ColumnModel[selectedColumns.size()]);
		}
	}
}
