package net.sourceforge.easysql.wizards;

import net.sourceforge.easysql.views.ConnectionView;
import net.sourceforge.easysql.views.connection.ConnectionModel;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class ConnectionWizard extends Wizard {
	ConnectionPage connectionPage;

	private ConnectionModel connectionModel;
    
    //To create a copy of the connectionModel
    private boolean createCopy = false;

    public void init(ConnectionModel model,boolean createCopy) {
        connectionModel = model;
        setWindowTitle("Edit Connection");
        this.createCopy=createCopy;
    }

	public void init(ConnectionModel model) {
		init(model,false);
	}

	public void init() {
		connectionModel = null;
		setWindowTitle("New Connection");
	}

	public boolean performFinish() {
		return connectionPage.performFinish();
	}

	public void addPages() {
		if (connectionModel != null) {
			connectionPage = new ConnectionPage("Edit Connection", connectionModel,createCopy);
		}
		else {
			connectionPage = new ConnectionPage("Add Connection",createCopy);
		}
		addPage(connectionPage);
	}
}

class ConnectionPage extends WizardPage {
	private String[] urlArray =
		{
			"jdbc:oracle:thin:@localhost:1521:",
			"jdbc:db2:",
			"jdbc:mysql:///",
			"jdbc:hsqldb:hsql://localhost",
			"jdbc:hsqldb:",
			"jdbc:sybase:Tds:co3061835-a:5000/",
			"jdbc:postgresql:" ,
			"com.pointbase.jdbc.jdbcUniversalDriver",
			"jdbc:pointbase:embedded:",
			"jdbc:sapdb://localhost/"	
		};

	private String[] driversArray =
		{
			"oracle.jdbc.driver.OracleDriver",
			"COM.ibm.db2.jdbc.app.DB2Driver",
			"org.gjt.mm.mysql.Driver",
			"org.hsqldb.jdbcDriver",
			"com.sybase.jdbc2.jdbc.SybDriver",
			"org.postgresql.Driver" ,
			"com.pointbase.jdbc.jdbcUniversalDriver",
			"interbase.interclient.Driver",
			"com.sap.dbtech.jdbc.DriverSapDB"};

	Text name;
	Text schema;
	Text username;
	Text password;
	Combo url;
	Combo driver;
	Text driverJar;
    Button showTables;
    Button showViews;

	ConnectionModel connectionModel = null;

	FileDialog dialog;
    
    boolean createCopy;

	public ConnectionPage(String pageName,boolean createCopy) {
		super(pageName);
		connectionModel = null;
        this.createCopy = createCopy;
	}

	public ConnectionPage(String pageName, ConnectionModel model,boolean createCopy) {
		super(pageName);
		this.connectionModel = model;
        this.createCopy = createCopy;
	}

	public void createControl(Composite parent) {
		dialog = new FileDialog(getContainer().getShell(), SWT.OPEN);
		dialog.setFilterExtensions(new String[] { "*.jar", "*.zip", "*.*" });
		dialog.setFilterNames(new String[] { "Jar Files (*.jar)", "Zip Files (*.zip)", "All Files (*.*)" });
		Composite container = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 2;
		layout.verticalSpacing = 9;

		Label label = new Label(container, SWT.NULL);
		label.setText("*Name");
		name = new Text(container, SWT.BORDER | SWT.SINGLE);
		name.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		label = new Label(container, SWT.NULL);
		label.setText("Schema");
		schema = new Text(container, SWT.BORDER | SWT.SINGLE);
		schema.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		label = new Label(container, SWT.NULL);
		label.setText("*Username");
		username = new Text(container, SWT.BORDER | SWT.SINGLE);
		username.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		label = new Label(container, SWT.NULL);
		label.setText("Password");
		password = new Text(container, SWT.BORDER | SWT.SINGLE);
		password.setEchoChar('*');
		password.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		label = new Label(container, SWT.NULL);
		label.setText("*URL");
		url = new Combo(container, SWT.NULL);
		url.setItems(urlArray);
		url.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		label = new Label(container, SWT.NULL);
		label.setText("*Driver");
		//driver = new Text(container, SWT.BORDER | SWT.SINGLE);
		//driver = new Combo(container, SWT.NULL | SWT.Deactivate);
		driver = new Combo(container, SWT.NULL);
		driver.setItems(driversArray);

		label = new Label(container, SWT.NULL);
		label.setText("*Driver JAR");
		driverJar = new Text(container, SWT.BORDER | SWT.SINGLE);
		driverJar.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		Button button = new Button(container, SWT.PUSH);
		button.setText("Browse...");
        button.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
        //label to fill the second column
        new Label(container, SWT.NULL);

		button.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
			}
			public void widgetSelected(SelectionEvent e) {
				String filename = dialog.open();
				if (filename != null) {
					driverJar.setText(filename);
				}
			}
		});
        
        //Show Tables & Views
        showTables = new Button(container, SWT.CHECK);
        showTables.setText("Show Tables");
        showTables.setSelection(true);
        showViews = new Button(container, SWT.CHECK);
        showViews.setText("Show Views");

		if (connectionModel != null) {
			if(!createCopy) {
				name.setText(connectionModel.getName());
			}
			schema.setText(connectionModel.getRealSchema());
			username.setText(connectionModel.getUsername());
			password.setText(connectionModel.getPassword());
			url.setText(connectionModel.getUrl());
			driver.setText(connectionModel.getDriver());
			driverJar.setText(connectionModel.getDriverJar());
            showTables.setSelection(new Boolean(connectionModel.getShowTables()).booleanValue());
            showViews.setSelection(new Boolean(connectionModel.getShowViews()).booleanValue());
		}

        if(createCopy) {
            //clean up to create another XML configuration
            connectionModel = null;
        }

		setControl(container);

		setPageComplete(true);
	}

	public boolean performFinish() {
		String nameText = name.getText().trim();
		// This doesn�t work with jdk 1.3
//		if (!XmlNames.isName(nameText)) {
//			MessageDialog.openError(
//				getShell(),
//				"Invalid Character",
//				"Name has an invalid character, please use alpha-numeric characters");
//			return false;
//		}

		String usernameText = username.getText().trim();

		// to use with Oracle
		String schemaText = schema.getText().trim();

		// Don't trim password!
		String passwordText = password.getText();
		String urlText = url.getText().trim();
		String driverText = driver.getText().trim();
		String driverJarText = driverJar.getText().trim();

		// Don't check if password is blank, cuz it can be!
		if (nameText.length() == 0
			|| usernameText.length() == 0
			|| urlText.length() == 0
			|| driverText.length() == 0
			|| driverJarText.length() == 0) {
			MessageDialog.openError(getShell(), "Required Fields", "Required field missing");
			return false;
		}

        boolean addNewConnection = false;

		if (connectionModel == null) {
			connectionModel = new ConnectionModel();
            addNewConnection = true;
        }

        connectionModel.setName(nameText);
		connectionModel.setSchema(schemaText);
		connectionModel.setUsername(usernameText);
		connectionModel.setPassword(passwordText);
		connectionModel.setUrl(urlText);
		connectionModel.setDriver(driverText);
		connectionModel.setDriverJar(driverJarText);
        connectionModel.setShowTables(String.valueOf(showTables.getSelection()));
        connectionModel.setShowViews(String.valueOf(showViews.getSelection()));

		if(addNewConnection) {
			ConnectionView.getInstance().addConnection(connectionModel);
        }
        else {
			ConnectionView.getInstance().changedConnection();
		}

		return true;
	}
}