package net.sourceforge.easysql.wizards;

import java.io.IOException;

import net.sourceforge.easysql.views.ConnectionView;
import net.sourceforge.easysql.views.MessageView;
import net.sourceforge.easysql.views.connection.ColumnModel;
import net.sourceforge.easysql.views.connection.ConnectionContentProvider;
import net.sourceforge.easysql.views.connection.InvisibleModel;
import net.sourceforge.easysql.views.connection.Model;

import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/**
 * @author Ricardo Lecheta
 */
public class InsertWizard extends TableColumnWizard {

	//	private String sql = null;

	private Logger log = Logger.getLogger(ExportWizard.class);

	private InsertPage insertPage;

	/**
	 * @param model
	 */
	public InsertWizard(Model model) {
		super(model);
		setWindowTitle("Insert Wizard");
	}

	public boolean performFinish() {
		try {
			return insertPage.performFinish();
		}
		catch (Exception e) {
			MessageDialog.openError(getContainer().getShell(), "Exception", e.getMessage());
		}
		return false;
	}

	public void addPages() {
		insertPage = new InsertPage("Insert");
		addPage(insertPage);
	}

	class InsertPage extends WizardPage {
		private Text[] texts = null;

		public InsertPage(String pageName) {
			super(pageName);
		}

		public void createControl(Composite parent) {
			Composite container = new Composite(parent, SWT.NULL);
			GridLayout gridLayout = new GridLayout();
			gridLayout.numColumns = 2;
			container.setLayout(gridLayout);

			GridData data = null;

            if(columns != null && columns.length > 0 && columns[0] instanceof InvisibleModel) {
                ConnectionContentProvider.getInstance().expandTableModel(tableModel, false);
                columns=tableModel.getChildren();
			}

            texts = new Text[columns.length];

			for (int i = 0; i < columns.length; i++) {
				ColumnModel column = (ColumnModel) columns[i];
				//if (!(column.is)) {
				new Label(container, SWT.PUSH).setText(column.getName());

				texts[i] = new Text(container, SWT.BORDER);
				data = new GridData();
				data.widthHint = 150;
				texts[i].setLayoutData(data);
				//} else // autoIncrement
				//	texts[i] = null;
			}

			//			lError = new Label(container, SWT.PUSH);
			//			lError.setForeground(getShell().getDisplay().getSystemColor(SWT.COLOR_RED));
			//			data = new GridData();
			//			data.widthHint = 500;
			//			lError.setLayoutData(data);

			setControl(container);
			setPageComplete(true);
		}

		public boolean performFinish() throws IOException {
			StringBuffer query = new StringBuffer("INSERT INTO " + tableModel.getName() + " (");

			for (int i = 0; i < columns.length; i++) {

				query.append(columns[i]);

				if(i != columns.length - 1 && (true)) {
					query.append(",");
				}
			}
			query.append(") VALUES(");

			for (int i = 0; i < texts.length; i++) {
				// autoIncrement
				if(texts[i] == null)
					continue;

				String text = texts[i].getText();
				if(text != null && text.trim().length() == 0) {
					query.append("null");
				}
				else {
					ColumnModel column = (ColumnModel) columns[i];
					if(column.isStringClass()) {
						query.append("'" + text + "'");
					}
					else {
						query.append(text);
					}
				}
				if(i != texts.length - 1 && (true)) {
					query.append(",");
				}
			}
			query.append(")");

			String insertQuery = query.toString();
			MessageView.getInstance().addMessage(insertQuery);
			try {
				MessageView.getInstance().addMessage(insertQuery);
				ConnectionContentProvider.getInstance().executeQuery(insertQuery);
				//ConnectionContentProvider.getInstance().executeQuery(sql);

                //refresh
                ConnectionView.getInstance().executeQuery(tableModel, false);
			}
			catch (Exception e) {
				MessageView.getInstance().addMessage(e.getMessage());
				log.error(e, e);
				//lError.setText(e.getMessage());
				MessageDialog.openError(getShell(), "Error", e.getMessage());
			}

			return false;
		}
	}
}