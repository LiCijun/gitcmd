package net.sourceforge.easysql.wizards;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import net.sourceforge.easysql.EasySQLPlugin;
import net.sourceforge.easysql.EasySQLUtils;
import net.sourceforge.easysql.views.ResultView;
import net.sourceforge.easysql.views.connection.ColumnModel;
import net.sourceforge.easysql.views.connection.ConnectionContentProvider;
import net.sourceforge.easysql.views.connection.TableModel;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;

/**
 * Export the current Table, using StringUtils.rightPad with the size of the
 * column
 * 
 * @author Ricardo Lecheta
 */
public class ExportWizard extends Wizard {

	private Logger log = Logger.getLogger(ExportWizard.class);
	ExportPage exportPage;

	public boolean performFinish() {
		try {
			return exportPage.performFinish();
		}
		catch (IOException e) {
			MessageDialog.openError(getContainer().getShell(), "IOException", e.getMessage());
		}
		return false;
	}

	public void addPages() {
		exportPage = new ExportPage("Export Data");
		addPage(exportPage);
	}

	class ExportPage extends WizardPage {

		Button includeFileHeaderButton;
		Button radioTable;
		Button radioSQL;
		//		Text separatorText;
		Text filenameText;
		FileDialog dialog;
        Text tableText;

		public ExportPage(String pageName) {
			super(pageName);
		}

		public void createControl(Composite parent) {
			Composite container = new Composite(parent, SWT.NULL);
			container.setLayout(new GridLayout(1, false));

			Composite subContainer = new Composite(container, SWT.NULL);
			subContainer.setLayout(new GridLayout(2, false));

			/** Include Column Names * */
			Label label = new Label(subContainer, SWT.LEFT);
			label.setText(" Include column names as first line of file");

			includeFileHeaderButton = new Button(subContainer, SWT.CHECK | SWT.RIGHT);
			includeFileHeaderButton.setSelection(true);
			includeFileHeaderButton.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_END));
			/** ----------------------------- * */

			Group group = new Group(subContainer, SWT.NONE);
			group.setText("Type");
			group.setLayout(new GridLayout(2, false));

			/** Export to SQL or Table * */
			radioTable = new Button(group, SWT.RADIO | SWT.RIGHT);
			radioTable.setSelection(true);
			radioTable.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_END));

			label = new Label(group, SWT.LEFT);
			label.setText(" Simple Table Layout");

			radioSQL = new Button(group, SWT.RADIO | SWT.RIGHT);
			radioSQL.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_END));
            radioSQL.addSelectionListener(new SelectionListener() {
				public void widgetSelected(SelectionEvent e) {
                    tableText.setEnabled(radioSQL.getSelection());
				}
				public void widgetDefaultSelected(SelectionEvent e) {
				}});

			label = new Label(group, SWT.LEFT);
			label.setText(" SQL");
			/** ----------------------------- * */

			Composite subContainer2 = new Composite(container, SWT.NULL);
			subContainer2.setLayout(new GridLayout(2, false));
			subContainer2.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

			// Export filenameText
			filenameText = new Text(subContainer2, SWT.BORDER | SWT.SINGLE);
			filenameText.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

			dialog = new FileDialog(getContainer().getShell(), SWT.OPEN);

			Button button = new Button(subContainer2, SWT.PUSH);
			button.setText("Browse...");

			button.addSelectionListener(new SelectionListener() {

				public void widgetDefaultSelected(SelectionEvent e) {
				}

				public void widgetSelected(SelectionEvent e) {
					String filename = dialog.open();
					if(filename != null) {
						filenameText.setText(filename);
					}
				}
			});
            
            // TABLE - to export to SQL
            group = new Group(subContainer2, SWT.NONE);
            group.setText("Table Name");
            group.setLayout(new GridLayout(2, false));
            group.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

            tableText = new Text(group, SWT.BORDER);
            tableText.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
            tableText.setEnabled(false);

			setControl(container);
			setPageComplete(true);
		}

		public boolean performFinish() throws IOException {

			log.debug("exporting data...");

			String filename = filenameText.getText();

			// Don't check if separator is blank, cuz it can be!
			if(filename.equals("")) {
				MessageDialog.openError(getShell(), "Required Fields", "Filename is required");
				return false;
			}

			// Export Data
			File file = new File(filename);

			// If exists, delete
			if(file.exists()) {
				file.delete();
			}

			FileOutputStream fos = null;
			try {
				file.createNewFile();
				fos = new FileOutputStream(file);
			}
			catch (FileNotFoundException e) {
				throw e;
			}

			Table selectedTable = ResultView.getInstance().getSelectedTable();

			TableColumn[] cols = selectedTable.getColumns();

			int size = 30;

			boolean includeFileHeader = includeFileHeaderButton.getSelection();

			//Export to the Table Layout
			if(radioTable.getSelection()) {
				exportToTableLayout(fos, selectedTable, cols, size, includeFileHeader);
			}
			else {
				exportToSQL(fos, selectedTable, cols, tableText.getText());
			}

			try {
				fos.flush();
			}
			catch (IOException e) {
				throw e;
			}

			try {
				fos.close();
			}
			catch (IOException e) {
				throw e;
			}

			log.debug("files exported successfully.");

			return true;
		}

		/**
		 * @param fos
		 * @param selectedTable
		 * @param cols
		 * @param size
		 * @param includeFileHeader
		 * @throws IOException
		 */
		private void exportToTableLayout(FileOutputStream fos, Table selectedTable, TableColumn[] cols, int size, boolean includeFileHeader)
				throws IOException {
			// Construct header
			StringBuffer buf = null;
			if(includeFileHeader) {
				buf = new StringBuffer();
				for (int i = 0; i < cols.length; i++) {

					try {
						size = cols[i].getWidth() / 5;
					}
					catch (Exception e) {

					}

					buf.append(StringUtils.rightPad(cols[i].getText(), size, " "));
				}
				try {
					buf.append(EasySQLPlugin.NEWLINE);
					fos.write(buf.toString().getBytes());
				}
				catch (IOException e) {
					throw e;
				}
				//				log.debug("DEBUG: (Header) " + buf.toString());
			}

			// Construct data, each row
			TableItem[] items = selectedTable.getItems();
			for (int i = 0; i < items.length; i++) {
				buf = new StringBuffer();

				// each column
				for (int x = 0; x < cols.length; x++) {

					try {
						size = cols[x].getWidth() / 5;
					}
					catch (Exception e) {

					}

					String text = StringUtils.rightPad(items[i].getText(x), size, " ");

					if(!text.equals("null")) {
						buf.append(text);
					}
					if(x != cols.length - 1) {
						//						buf.append(size);
					}
					else {
						//						log.debug("DEBUG: (Data) " + buf.toString());
						try {
							buf.append(EasySQLPlugin.NEWLINE);
							fos.write(buf.toString().getBytes());
						}
						catch (IOException e) {
							throw e;
						}
					}
				}
			}
		}
		/**
		 * @param fos
		 * @param selectedTable
		 * @param cols
		 */
		private void exportToSQL(FileOutputStream fos, Table selectedTable, TableColumn[] cols, String tableName) throws IOException {
			// Construct header
			StringBuffer buf = new StringBuffer();
            
            TableModel tableModel = EasySQLUtils.getTableModelByName(tableName);
            if(tableModel == null) {
                MessageDialog.openError(EasySQLPlugin.getShell(), "EasySQL", "Table not found");
                return;
            }

            Map mapCacheQuotes = new HashMap();

			// Construct data, each row
			TableItem[] items = selectedTable.getItems();
			for (int i = 0; i < items.length; i++) {
                
                buf.append("INSERT INTO " + tableName + "(");

				//INSERT INTO TABLE (...)
				for (int j = 0; j < cols.length; j++) {
					if(j != 0) {
						buf.append(",");
					}
					buf.append(cols[j].getText());
				}
				buf.append(") VALUES(");

				// each column/roow, X/Y
				for (int y = 0; y < cols.length; y++) {

					String text = items[i].getText(y);
					if(y != 0) {
						buf.append(",");
					}

                    Boolean b = (Boolean) mapCacheQuotes.get(cols[y].getText());
					boolean needQuotes = false; 
                    if(StringUtils.equals("<null>",text)) {
                        needQuotes = false;
                        text = null;   
                    }else {
                    	needQuotes = b != null ? b.booleanValue() : needQuotes(tableModel, cols[y].getText());
                    }
                    if(needQuotes) {
                        buf.append("'");
                    }
					buf.append(text);
                    if(needQuotes) {
                        buf.append("'");
                    }
				}

                buf.append(");\r\n");
			}
			
			fos.write(buf.toString().getBytes());
		}
	}

    /**
     * Put single quotes in Strings
     * 
     * @param tableModel
     * @param columnName
     * @return
     */
    private boolean needQuotes(TableModel tableModel,String columnName) {
        ColumnModel columnModel = (ColumnModel) tableModel.getChildByName(columnName);
        if(columnModel == null) {
            log.info("expanding table");
            ConnectionContentProvider.getInstance().expandTableModel(tableModel, false);
            columnModel = (ColumnModel) tableModel.getChildByName(columnName);
            if(columnModel == null) {
                log.info("column " + columnName + " not found");
                return false;
            }
        }
        return columnModel.isStringClass();
    }
}