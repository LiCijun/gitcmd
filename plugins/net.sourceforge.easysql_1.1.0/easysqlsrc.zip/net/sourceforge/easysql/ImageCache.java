package net.sourceforge.easysql;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.internal.util.BundleUtility;

/**
 * @author jtoth
 * @author Ricardo Lecheta
 * 
 * Last change to work with Eclipse 3.0.1
 */
public class ImageCache {

	private static Map descriptors = new HashMap();

	private static ImageRegistry imageRegistry = null;

	private final static String ICONS_PATH = "icons/";

	public static String CONNECTED_ICON = "connected_icon.gif";

	public static String SELECTED_CONNECTED_ICON = "selected_connected_icon.gif";

	public static String DISCONNECTED_ICON = "disconnected_icon.gif";

	public static String EXECUTE_ICON = "execute_icon.gif";

	public static String REMOVE_ICON = "remove_icon.gif";

	public static String DATABASE_ICON = "database_icon.gif";

	public static String SELECTED_DATABASE_ICON = "selected_database_icon.gif";

	public static String TABLE_ICON = "table_icon.gif";

    public static String VIEW_ICON = "view_icon.gif";

	public static String COLUMN_ICON = "column_icon.gif";

	public static String REFRESH_ICON = "refresh.gif";

	public static String RUN_ICON = "run.gif";

	public static String SQLEDITOR_ICON = "sqleditor.gif";

	public static String PK_ICON = "pk.gif";

	public static String FK_ICON = "fk.gif";

	public static String INSERT_ICON = "insert.gif";

	public static String COPY_ICON = "copy.gif";

	public static String IMPORT_ICON = "import.gif";
	public static String EXPORT_ICON = "export.gif";

	private ImageCache() {
	}

	static {
		initializeImageRegistry();
	}

	public static Image getImage(String key) {
		Image image = imageRegistry.get(key);
		if(image == null) {
			declareImage(key, ICONS_PATH + key, true);
			image = imageRegistry.get(key);
		}
		return image;
	}

	public static ImageDescriptor getImageDescriptor(String key) {
		ImageDescriptor descriptor = (ImageDescriptor) descriptors.get(key);
		if(descriptor == null) {
			declareImage(key, ICONS_PATH + key, true);
			descriptor = (ImageDescriptor) descriptors.get(key);
		}

		return descriptor;
	}

	private final static void declareImage(String key, String path, boolean shared) {
		URL url = BundleUtility.find("net.sourceforge.easysql", path);
		ImageDescriptor descriptor = ImageDescriptor.createFromURL(url);

		descriptors.put(key, descriptor);
		if(shared) {
			imageRegistry.put(key, descriptor);
		}
	}

	private static ImageRegistry initializeImageRegistry() {
		imageRegistry = new ImageRegistry();
		return imageRegistry;
	}
}